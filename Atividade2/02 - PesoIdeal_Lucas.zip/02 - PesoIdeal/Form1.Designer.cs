﻿
namespace PesoIdeal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.LblAltura = new System.Windows.Forms.Label();
            this.LblPeso = new System.Windows.Forms.Label();
            this.GbxSexo = new System.Windows.Forms.GroupBox();
            this.RbtnFem = new System.Windows.Forms.RadioButton();
            this.RbtnMasc = new System.Windows.Forms.RadioButton();
            this.MskbxAltura = new System.Windows.Forms.MaskedTextBox();
            this.MskbxPeso = new System.Windows.Forms.MaskedTextBox();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.GbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(33, 36);
            this.LblAltura.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(69, 25);
            this.LblAltura.TabIndex = 0;
            this.LblAltura.Text = "Altura";
            // 
            // LblPeso
            // 
            this.LblPeso.AutoSize = true;
            this.LblPeso.Location = new System.Drawing.Point(33, 123);
            this.LblPeso.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LblPeso.Name = "LblPeso";
            this.LblPeso.Size = new System.Drawing.Size(61, 25);
            this.LblPeso.TabIndex = 1;
            this.LblPeso.Text = "Peso";
            // 
            // GbxSexo
            // 
            this.GbxSexo.Controls.Add(this.RbtnFem);
            this.GbxSexo.Controls.Add(this.RbtnMasc);
            this.GbxSexo.Location = new System.Drawing.Point(38, 179);
            this.GbxSexo.Margin = new System.Windows.Forms.Padding(5);
            this.GbxSexo.Name = "GbxSexo";
            this.GbxSexo.Padding = new System.Windows.Forms.Padding(5);
            this.GbxSexo.Size = new System.Drawing.Size(262, 117);
            this.GbxSexo.TabIndex = 2;
            this.GbxSexo.TabStop = false;
            this.GbxSexo.Text = "Sexo";
            // 
            // RbtnFem
            // 
            this.RbtnFem.AutoSize = true;
            this.RbtnFem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RbtnFem.Location = new System.Drawing.Point(155, 49);
            this.RbtnFem.Margin = new System.Windows.Forms.Padding(5);
            this.RbtnFem.Name = "RbtnFem";
            this.RbtnFem.Size = new System.Drawing.Size(46, 29);
            this.RbtnFem.TabIndex = 4;
            this.RbtnFem.Text = "F";
            this.RbtnFem.UseVisualStyleBackColor = true;
            // 
            // RbtnMasc
            // 
            this.RbtnMasc.AutoSize = true;
            this.RbtnMasc.Checked = true;
            this.RbtnMasc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RbtnMasc.Location = new System.Drawing.Point(38, 49);
            this.RbtnMasc.Margin = new System.Windows.Forms.Padding(5);
            this.RbtnMasc.Name = "RbtnMasc";
            this.RbtnMasc.Size = new System.Drawing.Size(51, 29);
            this.RbtnMasc.TabIndex = 3;
            this.RbtnMasc.TabStop = true;
            this.RbtnMasc.Text = "M";
            this.RbtnMasc.UseVisualStyleBackColor = true;
            // 
            // MskbxAltura
            // 
            this.MskbxAltura.Location = new System.Drawing.Point(187, 36);
            this.MskbxAltura.Margin = new System.Windows.Forms.Padding(5);
            this.MskbxAltura.Mask = "0.00";
            this.MskbxAltura.Name = "MskbxAltura";
            this.MskbxAltura.Size = new System.Drawing.Size(113, 30);
            this.MskbxAltura.TabIndex = 3;
            this.MskbxAltura.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // MskbxPeso
            // 
            this.MskbxPeso.Location = new System.Drawing.Point(187, 123);
            this.MskbxPeso.Margin = new System.Windows.Forms.Padding(5);
            this.MskbxPeso.Mask = "000.00";
            this.MskbxPeso.Name = "MskbxPeso";
            this.MskbxPeso.Size = new System.Drawing.Size(113, 30);
            this.MskbxPeso.TabIndex = 4;
            this.MskbxPeso.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnCalcular.Location = new System.Drawing.Point(38, 345);
            this.BtnCalcular.Margin = new System.Windows.Forms.Padding(5);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(107, 65);
            this.BtnCalcular.TabIndex = 5;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnLimpar.Location = new System.Drawing.Point(193, 345);
            this.BtnLimpar.Margin = new System.Windows.Forms.Padding(5);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(107, 65);
            this.BtnLimpar.TabIndex = 6;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 609);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.MskbxPeso);
            this.Controls.Add(this.MskbxAltura);
            this.Controls.Add(this.GbxSexo);
            this.Controls.Add(this.LblPeso);
            this.Controls.Add(this.LblAltura);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Peso Ideal";
            this.GbxSexo.ResumeLayout(false);
            this.GbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label LblPeso;
        private System.Windows.Forms.GroupBox GbxSexo;
        private System.Windows.Forms.RadioButton RbtnFem;
        private System.Windows.Forms.RadioButton RbtnMasc;
        private System.Windows.Forms.MaskedTextBox MskbxAltura;
        private System.Windows.Forms.MaskedTextBox MskbxPeso;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Button BtnLimpar;
    }
}

