﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form
    {
        double Altura, Peso, PesoIdeal;

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            MskbxAltura.Clear();
            MskbxPeso.Clear();
            RbtnMasc.PerformClick();
        }

        public Form1()
        {
            InitializeComponent();

        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(MskbxAltura.Text, out Altura) &&
                double.TryParse(MskbxPeso.Text, out Peso))
            {
                if (RbtnMasc.Checked)
                {
                    PesoIdeal = (72.7 * Altura) - 58;
                    PesoIdeal = Math.Round(PesoIdeal, 2);
                }
                else
                {
                    PesoIdeal = (62.1 * Altura) - 44.7;
                    PesoIdeal = Math.Round(PesoIdeal, 2);
                }

                    if (Peso > PesoIdeal)
                        MessageBox.Show("Regime Obrigatório!");
                    else
                    if (Peso < PesoIdeal)
                        MessageBox.Show("Coma bastante massas e doces!");
                    else
                    MessageBox.Show("Você está com o peso ideal!");

            }
            else
                MessageBox.Show("Preencha todos os Campos!");

        }

    }
}
