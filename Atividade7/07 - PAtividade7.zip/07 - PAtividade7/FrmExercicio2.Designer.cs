﻿
namespace PAtividade7
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNumN = new System.Windows.Forms.Label();
            this.TxtNumN = new System.Windows.Forms.TextBox();
            this.BtnGeraNumH = new System.Windows.Forms.Button();
            this.LblValorH = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LblNumN
            // 
            this.LblNumN.AutoSize = true;
            this.LblNumN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNumN.Location = new System.Drawing.Point(33, 73);
            this.LblNumN.Name = "LblNumN";
            this.LblNumN.Size = new System.Drawing.Size(180, 20);
            this.LblNumN.TabIndex = 0;
            this.LblNumN.Text = "Informe um Número:";
            // 
            // TxtNumN
            // 
            this.TxtNumN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumN.Location = new System.Drawing.Point(277, 73);
            this.TxtNumN.Name = "TxtNumN";
            this.TxtNumN.Size = new System.Drawing.Size(206, 24);
            this.TxtNumN.TabIndex = 2;
            this.TxtNumN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnGeraNumH
            // 
            this.BtnGeraNumH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGeraNumH.Location = new System.Drawing.Point(310, 241);
            this.BtnGeraNumH.Name = "BtnGeraNumH";
            this.BtnGeraNumH.Size = new System.Drawing.Size(142, 96);
            this.BtnGeraNumH.TabIndex = 7;
            this.BtnGeraNumH.Text = "Gerar número \"H\"";
            this.BtnGeraNumH.UseVisualStyleBackColor = true;
            this.BtnGeraNumH.Click += new System.EventHandler(this.BtnGeraNumH_Click);
            // 
            // LblValorH
            // 
            this.LblValorH.AutoSize = true;
            this.LblValorH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblValorH.Location = new System.Drawing.Point(273, 169);
            this.LblValorH.Name = "LblValorH";
            this.LblValorH.Size = new System.Drawing.Size(73, 20);
            this.LblValorH.TabIndex = 8;
            this.LblValorH.Text = "Valor H";
            this.LblValorH.Visible = false;
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LblValorH);
            this.Controls.Add(this.BtnGeraNumH);
            this.Controls.Add(this.TxtNumN);
            this.Controls.Add(this.LblNumN);
            this.Name = "FrmExercicio2";
            this.Text = "Gera Valor H";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNumN;
        private System.Windows.Forms.TextBox TxtNumN;
        private System.Windows.Forms.Button BtnGeraNumH;
        private System.Windows.Forms.Label LblValorH;
    }
}