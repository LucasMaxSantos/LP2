﻿
namespace PAtividade7
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TlStpExercicioSair = new System.Windows.Forms.MenuStrip();
            this.TlStpExercicio1 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicio2 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicio3 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicio4 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpSair = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicioSair.SuspendLayout();
            this.SuspendLayout();
            // 
            // TlStpExercicioSair
            // 
            this.TlStpExercicioSair.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.TlStpExercicioSair.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TlStpExercicio1,
            this.TlStpExercicio2,
            this.TlStpExercicio3,
            this.TlStpExercicio4,
            this.TlStpSair});
            this.TlStpExercicioSair.Location = new System.Drawing.Point(0, 0);
            this.TlStpExercicioSair.Name = "TlStpExercicioSair";
            this.TlStpExercicioSair.Size = new System.Drawing.Size(815, 28);
            this.TlStpExercicioSair.TabIndex = 0;
            this.TlStpExercicioSair.Text = "menuStrip1";
            // 
            // TlStpExercicio1
            // 
            this.TlStpExercicio1.Name = "TlStpExercicio1";
            this.TlStpExercicio1.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio1.Text = "Exercício 1";
            this.TlStpExercicio1.Click += new System.EventHandler(this.TlStpExercicio1_Click);
            // 
            // TlStpExercicio2
            // 
            this.TlStpExercicio2.Name = "TlStpExercicio2";
            this.TlStpExercicio2.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio2.Text = "Exercício 2";
            this.TlStpExercicio2.Click += new System.EventHandler(this.TlStpExercicio2_Click);
            // 
            // TlStpExercicio3
            // 
            this.TlStpExercicio3.Name = "TlStpExercicio3";
            this.TlStpExercicio3.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio3.Text = "Exercício 3";
            this.TlStpExercicio3.Click += new System.EventHandler(this.TlStpExercicio3_Click);
            // 
            // TlStpExercicio4
            // 
            this.TlStpExercicio4.Name = "TlStpExercicio4";
            this.TlStpExercicio4.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio4.Text = "Exercício 4";
            this.TlStpExercicio4.Click += new System.EventHandler(this.TlStpExercicio4_Click);
            // 
            // TlStpSair
            // 
            this.TlStpSair.Name = "TlStpSair";
            this.TlStpSair.Size = new System.Drawing.Size(48, 24);
            this.TlStpSair.Text = "Sair";
            this.TlStpSair.Click += new System.EventHandler(this.TlStpSair_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 510);
            this.Controls.Add(this.TlStpExercicioSair);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.TlStpExercicioSair;
            this.Name = "FrmPrincipal";
            this.Text = "Menu Principal";
            this.TlStpExercicioSair.ResumeLayout(false);
            this.TlStpExercicioSair.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip TlStpExercicioSair;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio1;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio2;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio3;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio4;
        private System.Windows.Forms.ToolStripMenuItem TlStpSair;
    }
}

