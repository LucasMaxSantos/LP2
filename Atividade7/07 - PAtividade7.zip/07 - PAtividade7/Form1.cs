﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void TlStpExercicio1_Click(object sender, EventArgs e)
        {
            FrmExercicio1 objFrm1 = new FrmExercicio1();
            objFrm1.MdiParent = this;
            objFrm1.WindowState = FormWindowState.Maximized;
            objFrm1.Show();
        }

        private void TlStpExercicio2_Click(object sender, EventArgs e)
        {
            FrmExercicio2 objFrm2 = new FrmExercicio2();
            objFrm2.MdiParent = this;
            objFrm2.WindowState = FormWindowState.Maximized;
            objFrm2.Show();
        }

        private void TlStpExercicio3_Click(object sender, EventArgs e)
        {
            FrmExercicio3 objFrm3 = new FrmExercicio3();
            objFrm3.MdiParent = this;
            objFrm3.WindowState = FormWindowState.Maximized;
            objFrm3.Show();
        }

        private void TlStpExercicio4_Click(object sender, EventArgs e)
        {
            FrmExercicio4 objFrm4 = new FrmExercicio4();
            objFrm4.MdiParent = this;
            objFrm4.WindowState = FormWindowState.Maximized;
            objFrm4.Show();
        }

        private void TlStpSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
