﻿
namespace PAtividade7
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNumInscricao = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblCargo = new System.Windows.Forms.Label();
            this.LblSalario = new System.Windows.Forms.Label();
            this.LblProducao = new System.Windows.Forms.Label();
            this.LblGratificacao = new System.Windows.Forms.Label();
            this.TxtNumInscricao = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtCargo = new System.Windows.Forms.TextBox();
            this.MskbxSalario = new System.Windows.Forms.MaskedTextBox();
            this.MskbxProducao = new System.Windows.Forms.MaskedTextBox();
            this.BtnCalcSalario = new System.Windows.Forms.Button();
            this.MskbxGratificacao = new System.Windows.Forms.MaskedTextBox();
            this.Lblinforma = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LblNumInscricao
            // 
            this.LblNumInscricao.AutoSize = true;
            this.LblNumInscricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNumInscricao.Location = new System.Drawing.Point(12, 31);
            this.LblNumInscricao.Name = "LblNumInscricao";
            this.LblNumInscricao.Size = new System.Drawing.Size(189, 20);
            this.LblNumInscricao.TabIndex = 0;
            this.LblNumInscricao.Text = "Número de Inscrição:";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNome.Location = new System.Drawing.Point(12, 79);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(167, 20);
            this.LblNome.TabIndex = 1;
            this.LblNome.Text = "Nome Funcionário:";
            // 
            // LblCargo
            // 
            this.LblCargo.AutoSize = true;
            this.LblCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCargo.Location = new System.Drawing.Point(12, 125);
            this.LblCargo.Name = "LblCargo";
            this.LblCargo.Size = new System.Drawing.Size(65, 20);
            this.LblCargo.TabIndex = 2;
            this.LblCargo.Text = "Cargo:";
            // 
            // LblSalario
            // 
            this.LblSalario.AutoSize = true;
            this.LblSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSalario.Location = new System.Drawing.Point(12, 168);
            this.LblSalario.Name = "LblSalario";
            this.LblSalario.Size = new System.Drawing.Size(103, 20);
            this.LblSalario.TabIndex = 3;
            this.LblSalario.Text = "Salário R$:";
            // 
            // LblProducao
            // 
            this.LblProducao.AutoSize = true;
            this.LblProducao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblProducao.Location = new System.Drawing.Point(12, 213);
            this.LblProducao.Name = "LblProducao";
            this.LblProducao.Size = new System.Drawing.Size(94, 20);
            this.LblProducao.TabIndex = 4;
            this.LblProducao.Text = "Produção:";
            // 
            // LblGratificacao
            // 
            this.LblGratificacao.AutoSize = true;
            this.LblGratificacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblGratificacao.Location = new System.Drawing.Point(12, 255);
            this.LblGratificacao.Name = "LblGratificacao";
            this.LblGratificacao.Size = new System.Drawing.Size(174, 20);
            this.LblGratificacao.TabIndex = 5;
            this.LblGratificacao.Text = "Gratificação R$: (*)";
            // 
            // TxtNumInscricao
            // 
            this.TxtNumInscricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumInscricao.Location = new System.Drawing.Point(502, 31);
            this.TxtNumInscricao.Name = "TxtNumInscricao";
            this.TxtNumInscricao.Size = new System.Drawing.Size(181, 24);
            this.TxtNumInscricao.TabIndex = 6;
            // 
            // TxtNome
            // 
            this.TxtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNome.Location = new System.Drawing.Point(285, 79);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(398, 24);
            this.TxtNome.TabIndex = 7;
            // 
            // TxtCargo
            // 
            this.TxtCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCargo.Location = new System.Drawing.Point(285, 125);
            this.TxtCargo.Name = "TxtCargo";
            this.TxtCargo.Size = new System.Drawing.Size(398, 24);
            this.TxtCargo.TabIndex = 8;
            // 
            // MskbxSalario
            // 
            this.MskbxSalario.Location = new System.Drawing.Point(502, 168);
            this.MskbxSalario.Mask = "0000.00";
            this.MskbxSalario.Name = "MskbxSalario";
            this.MskbxSalario.Size = new System.Drawing.Size(180, 22);
            this.MskbxSalario.TabIndex = 9;
            this.MskbxSalario.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // MskbxProducao
            // 
            this.MskbxProducao.Location = new System.Drawing.Point(503, 213);
            this.MskbxProducao.Mask = "0000";
            this.MskbxProducao.Name = "MskbxProducao";
            this.MskbxProducao.Size = new System.Drawing.Size(180, 22);
            this.MskbxProducao.TabIndex = 11;
            this.MskbxProducao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.MskbxProducao.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // BtnCalcSalario
            // 
            this.BtnCalcSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCalcSalario.Location = new System.Drawing.Point(276, 355);
            this.BtnCalcSalario.Name = "BtnCalcSalario";
            this.BtnCalcSalario.Size = new System.Drawing.Size(239, 63);
            this.BtnCalcSalario.TabIndex = 12;
            this.BtnCalcSalario.Text = "Calcula Salário Bruto";
            this.BtnCalcSalario.UseVisualStyleBackColor = true;
            this.BtnCalcSalario.Click += new System.EventHandler(this.BtnCalcSalario_Click);
            // 
            // MskbxGratificacao
            // 
            this.MskbxGratificacao.Location = new System.Drawing.Point(502, 253);
            this.MskbxGratificacao.Mask = "0000.00";
            this.MskbxGratificacao.Name = "MskbxGratificacao";
            this.MskbxGratificacao.Size = new System.Drawing.Size(180, 22);
            this.MskbxGratificacao.TabIndex = 13;
            this.MskbxGratificacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Lblinforma
            // 
            this.Lblinforma.AutoSize = true;
            this.Lblinforma.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lblinforma.Location = new System.Drawing.Point(502, 280);
            this.Lblinforma.Name = "Lblinforma";
            this.Lblinforma.Size = new System.Drawing.Size(224, 17);
            this.Lblinforma.TabIndex = 14;
            this.Lblinforma.Text = "* Sem gratificação colocar \"0\"";
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 430);
            this.Controls.Add(this.Lblinforma);
            this.Controls.Add(this.MskbxGratificacao);
            this.Controls.Add(this.BtnCalcSalario);
            this.Controls.Add(this.MskbxProducao);
            this.Controls.Add(this.MskbxSalario);
            this.Controls.Add(this.TxtCargo);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtNumInscricao);
            this.Controls.Add(this.LblGratificacao);
            this.Controls.Add(this.LblProducao);
            this.Controls.Add(this.LblSalario);
            this.Controls.Add(this.LblCargo);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.LblNumInscricao);
            this.Name = "FrmExercicio4";
            this.Text = "Calcula Salário Bruto";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNumInscricao;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblCargo;
        private System.Windows.Forms.Label LblSalario;
        private System.Windows.Forms.Label LblProducao;
        private System.Windows.Forms.Label LblGratificacao;
        private System.Windows.Forms.TextBox TxtNumInscricao;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtCargo;
        private System.Windows.Forms.MaskedTextBox MskbxSalario;
        private System.Windows.Forms.MaskedTextBox MskbxProducao;
        private System.Windows.Forms.Button BtnCalcSalario;
        private System.Windows.Forms.MaskedTextBox MskbxGratificacao;
        private System.Windows.Forms.Label Lblinforma;
    }
}