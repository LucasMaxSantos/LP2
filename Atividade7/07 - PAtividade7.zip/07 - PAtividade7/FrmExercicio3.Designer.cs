﻿
namespace PAtividade7
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblPalavra = new System.Windows.Forms.Label();
            this.BtnVerifica = new System.Windows.Forms.Button();
            this.TxtFrase = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LblPalavra
            // 
            this.LblPalavra.AutoSize = true;
            this.LblPalavra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPalavra.Location = new System.Drawing.Point(23, 43);
            this.LblPalavra.Name = "LblPalavra";
            this.LblPalavra.Size = new System.Drawing.Size(255, 20);
            this.LblPalavra.TabIndex = 0;
            this.LblPalavra.Text = "Informe uma palavra ou frase";
            // 
            // BtnVerifica
            // 
            this.BtnVerifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVerifica.Location = new System.Drawing.Point(291, 232);
            this.BtnVerifica.Name = "BtnVerifica";
            this.BtnVerifica.Size = new System.Drawing.Size(204, 75);
            this.BtnVerifica.TabIndex = 2;
            this.BtnVerifica.Text = "Verificador de Palíndromo";
            this.BtnVerifica.UseVisualStyleBackColor = true;
            this.BtnVerifica.Click += new System.EventHandler(this.BtnVerifica_Click_1);
            // 
            // TxtFrase
            // 
            this.TxtFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFrase.Location = new System.Drawing.Point(27, 95);
            this.TxtFrase.Name = "TxtFrase";
            this.TxtFrase.Size = new System.Drawing.Size(744, 24);
            this.TxtFrase.TabIndex = 1;
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnVerifica);
            this.Controls.Add(this.TxtFrase);
            this.Controls.Add(this.LblPalavra);
            this.Name = "FrmExercicio3";
            this.Text = "Testa Palíndromos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPalavra;
        private System.Windows.Forms.Button BtnVerifica;
        private System.Windows.Forms.TextBox TxtFrase;
    }
}