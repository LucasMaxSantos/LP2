﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnVerifica_Click(object sender, EventArgs e)
        {

        }

        private void BtnVerifica_Click_1(object sender, EventArgs e)
        {
            string Frase = "";
            string Inverso = "";

            if (TxtFrase.Text == "")
                MessageBox.Show("Caixa de Texto vazia");
            else
            {
                if (TxtFrase.Text.Length > 50)
                    MessageBox.Show("Permitido frases com até 50 caracteres");
                else
                {
                   
                    Frase = TxtFrase.Text.ToUpper();
                    Frase = Frase.Replace(" ", ""); //substitui os espaços = " " por vazio ou remove = ""
                    Inverso = Frase;
                    char[] arr = Inverso.ToCharArray();
                    Array.Reverse(arr);

                    Inverso = "";
                    foreach (char c in arr)
                    {
                        Inverso += c.ToString();
                    }
                }
            }
            //Compara se é Palíndromo

            if (string.Compare(Frase, Inverso, true) == 0)
            {
                MessageBox.Show(Inverso + " é um palíndromo");
            }
            else
                MessageBox.Show(Inverso + " não é palíndromo");
        }
    }
}
