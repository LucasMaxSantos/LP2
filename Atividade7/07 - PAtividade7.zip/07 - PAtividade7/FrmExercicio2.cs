﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnGeraNumH_Click(object sender, EventArgs e)
        {
            double H = 0;
            if (TxtNumN.Text == "")
                MessageBox.Show("Dados nao podem ser vazios");
            else
            {
                if (int.TryParse(TxtNumN.Text, out int N))
                {
                    if (N > 0)
                    {
                        for (int i = 1; i <= N; i++)
                        {

                            H+= (double)1/i; // mesmo que H = H + (double)1/i
                        }
                    }
                    else
                        MessageBox.Show("Informe Números Maiores que Zero");
                }
                else
                    MessageBox.Show("Informe apenas Números inteiros");

                LblValorH.Visible = true;
                LblValorH.Text = "O valor de H é: " + H.ToString("N2");

            }
        }
    }
}
