﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnCalcSalario_Click(object sender, EventArgs e)
        {
            double A;
            int B = 0;
            int C = 0;
            int D = 0;
            int Producao;
            double Gratificacao;
            double SalBruto;

            if ((TxtNumInscricao.Text == "") || (TxtNome.Text == "") || (TxtCargo.Text == "") ||
                (MskbxSalario.Text == "    ,") || (MskbxProducao.Text == "") || (MskbxGratificacao.Text == "    ,"))
                MessageBox.Show("Preencha todos os campos");
            else
            {
                if ((TxtNome.Text.Length < 8))
                {
                    MessageBox.Show("Nome inválido!");
                    TxtNome.Focus();
                }
                else
                {
                    A = Convert.ToDouble(MskbxSalario.Text);
                    Producao = Convert.ToInt16(MskbxProducao.Text);
                    Gratificacao = Convert.ToDouble(MskbxGratificacao.Text);

                    // verifica  quantidade produzida
                    if (Producao >= 100)
                        B = 1;
                    if (Producao >= 120)
                        C = 1;
                    if (Producao >= 150)
                        D = 1;

                    SalBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao;

                    if (SalBruto <= 7000)
                        MessageBox.Show("O Salário Bruto é: R$ " + SalBruto.ToString("N2"));

                    else if ((SalBruto > 7000) && (Producao >= 150) && Gratificacao > 0)
                        MessageBox.Show("O Salário Bruto é: R$ " + SalBruto.ToString("N2"));

                    else
                    {
                        MessageBox.Show("Aviso Salário Bruto calculado é maior que R$ 7000,00 " +
                            "porem produção inferiro a 150 ou sem gratificação");
                    }
                }
            }
        }
    }
}
