﻿
namespace Pmetodos
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblPalavra2 = new System.Windows.Forms.Label();
            this.LblPalavra1 = new System.Windows.Forms.Label();
            this.TxtPalavra1 = new System.Windows.Forms.TextBox();
            this.TxtPalavra2 = new System.Windows.Forms.TextBox();
            this.BtnVerificaIguais = new System.Windows.Forms.Button();
            this.BtnInserir1 = new System.Windows.Forms.Button();
            this.BtnInserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblPalavra2
            // 
            this.LblPalavra2.AutoSize = true;
            this.LblPalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPalavra2.Location = new System.Drawing.Point(64, 143);
            this.LblPalavra2.Name = "LblPalavra2";
            this.LblPalavra2.Size = new System.Drawing.Size(88, 20);
            this.LblPalavra2.TabIndex = 1;
            this.LblPalavra2.Text = "Palavra 2";
            // 
            // LblPalavra1
            // 
            this.LblPalavra1.AutoSize = true;
            this.LblPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPalavra1.Location = new System.Drawing.Point(64, 82);
            this.LblPalavra1.Name = "LblPalavra1";
            this.LblPalavra1.Size = new System.Drawing.Size(88, 20);
            this.LblPalavra1.TabIndex = 0;
            this.LblPalavra1.Text = "Palavra 1";
            // 
            // TxtPalavra1
            // 
            this.TxtPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPalavra1.Location = new System.Drawing.Point(169, 76);
            this.TxtPalavra1.Name = "TxtPalavra1";
            this.TxtPalavra1.Size = new System.Drawing.Size(327, 27);
            this.TxtPalavra1.TabIndex = 2;
            this.TxtPalavra1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtPalavra2
            // 
            this.TxtPalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPalavra2.Location = new System.Drawing.Point(169, 138);
            this.TxtPalavra2.Name = "TxtPalavra2";
            this.TxtPalavra2.Size = new System.Drawing.Size(327, 27);
            this.TxtPalavra2.TabIndex = 3;
            this.TxtPalavra2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnVerificaIguais
            // 
            this.BtnVerificaIguais.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVerificaIguais.Location = new System.Drawing.Point(68, 273);
            this.BtnVerificaIguais.Name = "BtnVerificaIguais";
            this.BtnVerificaIguais.Size = new System.Drawing.Size(169, 103);
            this.BtnVerificaIguais.TabIndex = 4;
            this.BtnVerificaIguais.Text = "Vericar se 1° e 2° são iguais";
            this.BtnVerificaIguais.UseVisualStyleBackColor = true;
            this.BtnVerificaIguais.Click += new System.EventHandler(this.BtnVerificaIguais_Click);
            // 
            // BtnInserir1
            // 
            this.BtnInserir1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInserir1.Location = new System.Drawing.Point(297, 273);
            this.BtnInserir1.Name = "BtnInserir1";
            this.BtnInserir1.Size = new System.Drawing.Size(169, 103);
            this.BtnInserir1.TabIndex = 5;
            this.BtnInserir1.Text = "Inseriro 1° no meio do 2°";
            this.BtnInserir1.UseVisualStyleBackColor = true;
            this.BtnInserir1.Click += new System.EventHandler(this.BtnInserir1_Click);
            // 
            // BtnInserir2
            // 
            this.BtnInserir2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInserir2.Location = new System.Drawing.Point(535, 273);
            this.BtnInserir2.Name = "BtnInserir2";
            this.BtnInserir2.Size = new System.Drawing.Size(169, 103);
            this.BtnInserir2.TabIndex = 6;
            this.BtnInserir2.Text = "Inserir ** no meio do 1°";
            this.BtnInserir2.UseVisualStyleBackColor = true;
            this.BtnInserir2.Click += new System.EventHandler(this.BtnInserir2_Click);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnInserir2);
            this.Controls.Add(this.BtnInserir1);
            this.Controls.Add(this.BtnVerificaIguais);
            this.Controls.Add(this.TxtPalavra2);
            this.Controls.Add(this.TxtPalavra1);
            this.Controls.Add(this.LblPalavra2);
            this.Controls.Add(this.LblPalavra1);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPalavra2;
        private System.Windows.Forms.Label LblPalavra1;
        private System.Windows.Forms.TextBox TxtPalavra1;
        private System.Windows.Forms.TextBox TxtPalavra2;
        private System.Windows.Forms.Button BtnVerificaIguais;
        private System.Windows.Forms.Button BtnInserir1;
        private System.Windows.Forms.Button BtnInserir2;
    }
}