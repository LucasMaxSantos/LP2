﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSorteio_Click(object sender, EventArgs e)
        {

            if ((TxtNumero1.Text == "") || (TxtNumero2.Text == ""))
                MessageBox.Show("Dados nao podem ser vazios");
            else
            {
                if (int.TryParse(TxtNumero1.Text, out int Numero1) && 
                    int.TryParse(TxtNumero2.Text, out int Numero2))
                {
                    if (Numero1 < 0 || Numero2 < 0) // verica se os números informados são maior ou igual 0
                        MessageBox.Show("Informe Números Maiores que Zero");

                    else if (Numero1 < Numero2)
                    {
                        Random random = new Random();                   // gerar um numero aleatório a partir 
                        int Resultado = random.Next(Numero1, Numero2); // do que foi digitado pelo usuario
                        MessageBox.Show("O Número sorteado é: " + Resultado.ToString()); 
                    }
                    else if (Numero1 == Numero2)
                        MessageBox.Show("Não a Sorteio Entre Números Iguais");
                    else
                        MessageBox.Show("O 2° Número deve ser Maior que o 1°");
                }
                else
                    MessageBox.Show("Permitido apenas Números inteiros");
            }
        }
    }
}
