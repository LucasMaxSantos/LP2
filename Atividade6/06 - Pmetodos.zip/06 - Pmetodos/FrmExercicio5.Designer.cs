﻿
namespace Pmetodos
{
    partial class FrmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNumero1 = new System.Windows.Forms.Label();
            this.LblNumero2 = new System.Windows.Forms.Label();
            this.TxtNumero1 = new System.Windows.Forms.TextBox();
            this.TxtNumero2 = new System.Windows.Forms.TextBox();
            this.BtnSorteio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblNumero1
            // 
            this.LblNumero1.AutoSize = true;
            this.LblNumero1.Location = new System.Drawing.Point(141, 74);
            this.LblNumero1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblNumero1.Name = "LblNumero1";
            this.LblNumero1.Size = new System.Drawing.Size(98, 20);
            this.LblNumero1.TabIndex = 0;
            this.LblNumero1.Text = "1° Número";
            // 
            // LblNumero2
            // 
            this.LblNumero2.AutoSize = true;
            this.LblNumero2.Location = new System.Drawing.Point(141, 133);
            this.LblNumero2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblNumero2.Name = "LblNumero2";
            this.LblNumero2.Size = new System.Drawing.Size(98, 20);
            this.LblNumero2.TabIndex = 1;
            this.LblNumero2.Text = "2° Número";
            // 
            // TxtNumero1
            // 
            this.TxtNumero1.Location = new System.Drawing.Point(346, 74);
            this.TxtNumero1.Margin = new System.Windows.Forms.Padding(4);
            this.TxtNumero1.Name = "TxtNumero1";
            this.TxtNumero1.Size = new System.Drawing.Size(103, 27);
            this.TxtNumero1.TabIndex = 2;
            this.TxtNumero1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtNumero2
            // 
            this.TxtNumero2.Location = new System.Drawing.Point(346, 133);
            this.TxtNumero2.Margin = new System.Windows.Forms.Padding(4);
            this.TxtNumero2.Name = "TxtNumero2";
            this.TxtNumero2.Size = new System.Drawing.Size(103, 27);
            this.TxtNumero2.TabIndex = 3;
            this.TxtNumero2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnSorteio
            // 
            this.BtnSorteio.Location = new System.Drawing.Point(201, 251);
            this.BtnSorteio.Name = "BtnSorteio";
            this.BtnSorteio.Size = new System.Drawing.Size(174, 76);
            this.BtnSorteio.TabIndex = 4;
            this.BtnSorteio.Text = "Sorteio";
            this.BtnSorteio.UseVisualStyleBackColor = true;
            this.BtnSorteio.Click += new System.EventHandler(this.BtnSorteio_Click);
            // 
            // FrmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 484);
            this.Controls.Add(this.BtnSorteio);
            this.Controls.Add(this.TxtNumero2);
            this.Controls.Add(this.TxtNumero1);
            this.Controls.Add(this.LblNumero2);
            this.Controls.Add(this.LblNumero1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmExercicio5";
            this.Text = "FrmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNumero1;
        private System.Windows.Forms.Label LblNumero2;
        private System.Windows.Forms.TextBox TxtNumero1;
        private System.Windows.Forms.TextBox TxtNumero2;
        private System.Windows.Forms.Button BtnSorteio;
    }
}