﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnRemover1_Click(object sender, EventArgs e)
        {
            //a         s           tec
            //casa    assessoria    fatec
            //cs       aeoria       fa


            if ((TxtPalavra1.Text == "") || (TxtPalavra2.Text == ""))

                MessageBox.Show("Dados nao podem ser vazios");

            else
            {
                int posicao = TxtPalavra2.Text.IndexOf(TxtPalavra1.Text);



                while (posicao >= 0)
                {
                    TxtPalavra2.Text = TxtPalavra2.Text.Substring(0, posicao) +
                    TxtPalavra2.Text.Substring(posicao + TxtPalavra1.Text.Length,
                    TxtPalavra2.Text.Length - posicao - TxtPalavra1.Text.Length);



                    posicao = TxtPalavra2.Text.IndexOf(TxtPalavra1.Text);
                }

            }
        }

        private void BtnRemover2_Click(object sender, EventArgs e)
        {
            if ((TxtPalavra1.Text == "") || (TxtPalavra2.Text == ""))

                MessageBox.Show("Dados nao podem ser vazios");

            else
            {
                TxtPalavra2.Text = TxtPalavra2.Text.Replace(TxtPalavra1.Text, "");
            }
        }

        private void BtnInverte_Click(object sender, EventArgs e)
        {
            if ((TxtPalavra1.Text == "") )

                MessageBox.Show("Campo 1 não pode ficar vazio");
            else
            {
                char[] texto = TxtPalavra1.Text.ToCharArray(); // Sorocaba



                Array.Reverse(texto); // abacoroS


                TxtPalavra2.Text = "";
                foreach (char c in texto)
                {
                    TxtPalavra2.Text += c;
                }
            }
        }
    }
}
