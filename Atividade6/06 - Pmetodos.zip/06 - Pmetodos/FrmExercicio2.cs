﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnVerificaIguais_Click(object sender, EventArgs e)
        {
            if (String.Compare(TxtPalavra1.Text, TxtPalavra2.Text, true) == 0)
            {
                MessageBox.Show("São iguais");
            }
            else
            {
                MessageBox.Show("São diferentes");
            }
        }

        private void BtnInserir1_Click(object sender, EventArgs e)
        {
            int metade = TxtPalavra2.Text.Length / 2;
            TxtPalavra2.Text = TxtPalavra2.Text.Substring(0, metade) +
                TxtPalavra1.Text + TxtPalavra2.Text.Substring(metade,
                TxtPalavra2.Text.Length - metade);
        }

        private void BtnInserir2_Click(object sender, EventArgs e)
        {
            if ((TxtPalavra1.Text == "") || (TxtPalavra2.Text == ""))

                MessageBox.Show("Dados nao podem ser vazios");

            else
            {
                int metade = TxtPalavra1.Text.Length / 2;
                TxtPalavra2.Text = TxtPalavra1.Text.Insert(metade, "**");
            }
        }
    }
}
