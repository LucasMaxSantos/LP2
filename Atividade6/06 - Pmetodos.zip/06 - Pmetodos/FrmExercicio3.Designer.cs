﻿
namespace Pmetodos
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtPalavra1 = new System.Windows.Forms.TextBox();
            this.TxtPalavra2 = new System.Windows.Forms.TextBox();
            this.BtnRemover1 = new System.Windows.Forms.Button();
            this.BtnRemover2 = new System.Windows.Forms.Button();
            this.BtnInverte = new System.Windows.Forms.Button();
            this.LblPalavra1 = new System.Windows.Forms.Label();
            this.LblPalavra2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TxtPalavra1
            // 
            this.TxtPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPalavra1.Location = new System.Drawing.Point(210, 40);
            this.TxtPalavra1.Name = "TxtPalavra1";
            this.TxtPalavra1.Size = new System.Drawing.Size(329, 27);
            this.TxtPalavra1.TabIndex = 0;
            this.TxtPalavra1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtPalavra2
            // 
            this.TxtPalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPalavra2.Location = new System.Drawing.Point(210, 111);
            this.TxtPalavra2.Name = "TxtPalavra2";
            this.TxtPalavra2.Size = new System.Drawing.Size(329, 27);
            this.TxtPalavra2.TabIndex = 1;
            this.TxtPalavra2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnRemover1
            // 
            this.BtnRemover1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRemover1.Location = new System.Drawing.Point(62, 268);
            this.BtnRemover1.Name = "BtnRemover1";
            this.BtnRemover1.Size = new System.Drawing.Size(160, 92);
            this.BtnRemover1.TabIndex = 2;
            this.BtnRemover1.Text = "Remove 1° do 2°";
            this.BtnRemover1.UseVisualStyleBackColor = true;
            this.BtnRemover1.Click += new System.EventHandler(this.BtnRemover1_Click);
            // 
            // BtnRemover2
            // 
            this.BtnRemover2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRemover2.Location = new System.Drawing.Point(288, 268);
            this.BtnRemover2.Name = "BtnRemover2";
            this.BtnRemover2.Size = new System.Drawing.Size(160, 92);
            this.BtnRemover2.TabIndex = 3;
            this.BtnRemover2.Text = "Remove 1º do 2º (Replace)";
            this.BtnRemover2.UseVisualStyleBackColor = true;
            this.BtnRemover2.Click += new System.EventHandler(this.BtnRemover2_Click);
            // 
            // BtnInverte
            // 
            this.BtnInverte.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInverte.Location = new System.Drawing.Point(504, 268);
            this.BtnInverte.Name = "BtnInverte";
            this.BtnInverte.Size = new System.Drawing.Size(160, 92);
            this.BtnInverte.TabIndex = 4;
            this.BtnInverte.Text = "Inverte o 1º";
            this.BtnInverte.UseVisualStyleBackColor = true;
            this.BtnInverte.Click += new System.EventHandler(this.BtnInverte_Click);
            // 
            // LblPalavra1
            // 
            this.LblPalavra1.AutoSize = true;
            this.LblPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPalavra1.Location = new System.Drawing.Point(59, 40);
            this.LblPalavra1.Name = "LblPalavra1";
            this.LblPalavra1.Size = new System.Drawing.Size(88, 20);
            this.LblPalavra1.TabIndex = 5;
            this.LblPalavra1.Text = "Palavra 1";
            // 
            // LblPalavra2
            // 
            this.LblPalavra2.AutoSize = true;
            this.LblPalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPalavra2.Location = new System.Drawing.Point(59, 111);
            this.LblPalavra2.Name = "LblPalavra2";
            this.LblPalavra2.Size = new System.Drawing.Size(88, 20);
            this.LblPalavra2.TabIndex = 6;
            this.LblPalavra2.Text = "Palavra 2";
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 450);
            this.Controls.Add(this.LblPalavra2);
            this.Controls.Add(this.LblPalavra1);
            this.Controls.Add(this.BtnInverte);
            this.Controls.Add(this.BtnRemover2);
            this.Controls.Add(this.BtnRemover1);
            this.Controls.Add(this.TxtPalavra2);
            this.Controls.Add(this.TxtPalavra1);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtPalavra1;
        private System.Windows.Forms.TextBox TxtPalavra2;
        private System.Windows.Forms.Button BtnRemover1;
        private System.Windows.Forms.Button BtnRemover2;
        private System.Windows.Forms.Button BtnInverte;
        private System.Windows.Forms.Label LblPalavra1;
        private System.Windows.Forms.Label LblPalavra2;
    }
}