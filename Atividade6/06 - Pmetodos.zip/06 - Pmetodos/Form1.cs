﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void SairToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void CopiarToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Entrei na opção copiar");
        }

        private void ColarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrei na opção colar");
        }

        private void Exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio2 objFrm2 = new FrmExercicio2();
            objFrm2.MdiParent = this;
            objFrm2.WindowState = FormWindowState.Maximized;
            objFrm2.Show();
        }

        private void Exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio3 objFrm3 = new FrmExercicio3();
            objFrm3.MdiParent = this;
            objFrm3.WindowState = FormWindowState.Maximized;
            objFrm3.Show();
        }

        private void Exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio4 objFrm4 = new FrmExercicio4();
            objFrm4.MdiParent = this;
            objFrm4.WindowState = FormWindowState.Maximized;
            objFrm4.Show();
        }

        private void Exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio5 objFrm5 = new FrmExercicio5();
            objFrm5.MdiParent = this;
            objFrm5.WindowState = FormWindowState.Maximized;
            objFrm5.Show();
        }
    }
}
