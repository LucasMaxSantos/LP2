﻿
namespace Pmetodos
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RchTxtMensagem = new System.Windows.Forms.RichTextBox();
            this.BtnContNum = new System.Windows.Forms.Button();
            this.BtnCarcterEmBranco = new System.Windows.Forms.Button();
            this.BtnContLetras = new System.Windows.Forms.Button();
            this.LblDescricao = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // RchTxtMensagem
            // 
            this.RchTxtMensagem.Location = new System.Drawing.Point(101, 43);
            this.RchTxtMensagem.Name = "RchTxtMensagem";
            this.RchTxtMensagem.Size = new System.Drawing.Size(578, 243);
            this.RchTxtMensagem.TabIndex = 0;
            this.RchTxtMensagem.Text = "";
            // 
            // BtnContNum
            // 
            this.BtnContNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnContNum.Location = new System.Drawing.Point(101, 316);
            this.BtnContNum.Name = "BtnContNum";
            this.BtnContNum.Size = new System.Drawing.Size(142, 96);
            this.BtnContNum.TabIndex = 1;
            this.BtnContNum.Text = "Conta Caracteres Numéricos";
            this.BtnContNum.UseVisualStyleBackColor = true;
            this.BtnContNum.Click += new System.EventHandler(this.BtnContNum_Click);
            // 
            // BtnCarcterEmBranco
            // 
            this.BtnCarcterEmBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCarcterEmBranco.Location = new System.Drawing.Point(320, 316);
            this.BtnCarcterEmBranco.Name = "BtnCarcterEmBranco";
            this.BtnCarcterEmBranco.Size = new System.Drawing.Size(142, 96);
            this.BtnCarcterEmBranco.TabIndex = 2;
            this.BtnCarcterEmBranco.Text = "Posição do 1° Caracter em Branco";
            this.BtnCarcterEmBranco.UseVisualStyleBackColor = true;
            this.BtnCarcterEmBranco.Click += new System.EventHandler(this.BtnCarcterEmBranco_Click);
            // 
            // BtnContLetras
            // 
            this.BtnContLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnContLetras.Location = new System.Drawing.Point(537, 316);
            this.BtnContLetras.Name = "BtnContLetras";
            this.BtnContLetras.Size = new System.Drawing.Size(142, 96);
            this.BtnContLetras.TabIndex = 3;
            this.BtnContLetras.Text = "Conta Caracteres Alfabéticos";
            this.BtnContLetras.UseVisualStyleBackColor = true;
            this.BtnContLetras.Click += new System.EventHandler(this.BtnContLetras_Click);
            // 
            // LblDescricao
            // 
            this.LblDescricao.AutoSize = true;
            this.LblDescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDescricao.Location = new System.Drawing.Point(101, 13);
            this.LblDescricao.Name = "LblDescricao";
            this.LblDescricao.Size = new System.Drawing.Size(285, 20);
            this.LblDescricao.TabIndex = 4;
            this.LblDescricao.Text = "Entre com a mensagem ou Texto";
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LblDescricao);
            this.Controls.Add(this.BtnContLetras);
            this.Controls.Add(this.BtnCarcterEmBranco);
            this.Controls.Add(this.BtnContNum);
            this.Controls.Add(this.RchTxtMensagem);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox RchTxtMensagem;
        private System.Windows.Forms.Button BtnContNum;
        private System.Windows.Forms.Button BtnCarcterEmBranco;
        private System.Windows.Forms.Button BtnContLetras;
        private System.Windows.Forms.Label LblDescricao;
    }
}