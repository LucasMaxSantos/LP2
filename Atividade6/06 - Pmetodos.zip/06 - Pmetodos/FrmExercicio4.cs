﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnContNum_Click(object sender, EventArgs e)
        {
            int Cont = 0;
  


            if ( (RchTxtMensagem.Text == ""))
                MessageBox.Show("Caixa de texto Vazia");
            else
            {
                string Texto = RchTxtMensagem.Text; //atribui a String digitada no RichText para a variavel texto
                int Tamanho = RchTxtMensagem.Text.Length;// Comando Lenght para identificar o comprimento da String
                for (int i = 0; i < Tamanho; i++)
                    if (char.IsNumber(Texto[i])) //verifica se o caracter na posição i é numero
                    {
                        Cont++;
                    }

                if (Cont > 0)
                    MessageBox.Show("O numero de Caractere(s) Numérico(s) é: " + Cont);
                else
                    MessageBox.Show("Não Há Caractere(s) Numerico(s)");

            }


        }

        private void BtnCarcterEmBranco_Click(object sender, EventArgs e)
        {
            int i = 0;
            int Posicao = 0;
            if ((RchTxtMensagem.Text == ""))
                MessageBox.Show("Caixa de texto Vazia");
            else
            {
                
                string Texto = RchTxtMensagem.Text; //atribui a String digitada no RichText para a variavel texto
                while (i < Texto.Length)
                {
                    if (!char.IsWhiteSpace(Texto[i])) // Se Diferente de Vazio conte
                    {
                        i++;
                    }
                    else
                    {
                        Posicao = i;
                        break;
                    }
                }

                if (Posicao > 0)
                    MessageBox.Show("A 1° posição em Branco é a: N° " + Posicao);
                else
                    MessageBox.Show("Não há nenhuma posição em Branco:");

            }
        }

        private void BtnContLetras_Click(object sender, EventArgs e)
        {
            int Cont = 0;
            if ((RchTxtMensagem.Text == ""))
                MessageBox.Show("Caixa de texto Vazia");
            else
            {
                
                foreach(char i in RchTxtMensagem.Text)
                    if (char.IsLetter(i))
                    {
                        Cont++;
                    }
                if (Cont > 0)
                    MessageBox.Show("O numero de Caractere(s) alfabético(s) é: " + Cont);
                else
                    MessageBox.Show("Não Há Caracteres alfabéticos");
            }

        }
    }
}
