﻿
namespace Pmetodos
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MnStpExercicios = new System.Windows.Forms.MenuStrip();
            this.Exercício2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CopiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ColarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Exercício3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Exercício4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Exercício5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editorDeTextoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MnStpExercicios.SuspendLayout();
            this.ContextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnStpExercicios
            // 
            this.MnStpExercicios.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.MnStpExercicios.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Exercício2ToolStripMenuItem,
            this.Exercício3ToolStripMenuItem,
            this.Exercício4ToolStripMenuItem,
            this.Exercício5ToolStripMenuItem,
            this.SairToolStripMenuItem});
            this.MnStpExercicios.Location = new System.Drawing.Point(0, 0);
            this.MnStpExercicios.Name = "MnStpExercicios";
            this.MnStpExercicios.Size = new System.Drawing.Size(866, 28);
            this.MnStpExercicios.TabIndex = 1;
            this.MnStpExercicios.Text = "menuStrip2";
            // 
            // Exercício2ToolStripMenuItem
            // 
            this.Exercício2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CopiarToolStripMenuItem,
            this.ColarToolStripMenuItem});
            this.Exercício2ToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exercício2ToolStripMenuItem.Name = "Exercício2ToolStripMenuItem";
            this.Exercício2ToolStripMenuItem.Size = new System.Drawing.Size(97, 24);
            this.Exercício2ToolStripMenuItem.Text = "Exercício &2";
            this.Exercício2ToolStripMenuItem.Click += new System.EventHandler(this.Exercício2ToolStripMenuItem_Click);
            // 
            // CopiarToolStripMenuItem
            // 
            this.CopiarToolStripMenuItem.Name = "CopiarToolStripMenuItem";
            this.CopiarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.CopiarToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.CopiarToolStripMenuItem.Text = "Copiar";
            this.CopiarToolStripMenuItem.Click += new System.EventHandler(this.CopiarToolStripMenuItem_Click_1);
            // 
            // ColarToolStripMenuItem
            // 
            this.ColarToolStripMenuItem.Name = "ColarToolStripMenuItem";
            this.ColarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.ColarToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.ColarToolStripMenuItem.Text = "Colar";
            this.ColarToolStripMenuItem.Click += new System.EventHandler(this.ColarToolStripMenuItem_Click);
            // 
            // Exercício3ToolStripMenuItem
            // 
            this.Exercício3ToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exercício3ToolStripMenuItem.Name = "Exercício3ToolStripMenuItem";
            this.Exercício3ToolStripMenuItem.Size = new System.Drawing.Size(97, 24);
            this.Exercício3ToolStripMenuItem.Text = "Exercício &3";
            this.Exercício3ToolStripMenuItem.Click += new System.EventHandler(this.Exercício3ToolStripMenuItem_Click);
            // 
            // Exercício4ToolStripMenuItem
            // 
            this.Exercício4ToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exercício4ToolStripMenuItem.Name = "Exercício4ToolStripMenuItem";
            this.Exercício4ToolStripMenuItem.Size = new System.Drawing.Size(97, 24);
            this.Exercício4ToolStripMenuItem.Text = "Exercício &4";
            this.Exercício4ToolStripMenuItem.Click += new System.EventHandler(this.Exercício4ToolStripMenuItem_Click);
            // 
            // Exercício5ToolStripMenuItem
            // 
            this.Exercício5ToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exercício5ToolStripMenuItem.Name = "Exercício5ToolStripMenuItem";
            this.Exercício5ToolStripMenuItem.Size = new System.Drawing.Size(97, 24);
            this.Exercício5ToolStripMenuItem.Text = "Exercício &5";
            this.Exercício5ToolStripMenuItem.Click += new System.EventHandler(this.Exercício5ToolStripMenuItem_Click);
            // 
            // SairToolStripMenuItem
            // 
            this.SairToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SairToolStripMenuItem.Name = "SairToolStripMenuItem";
            this.SairToolStripMenuItem.Size = new System.Drawing.Size(49, 24);
            this.SairToolStripMenuItem.Text = "&Sair";
            this.SairToolStripMenuItem.Click += new System.EventHandler(this.SairToolStripMenuItem_Click_1);
            // 
            // ContextMenuStrip1
            // 
            this.ContextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editorDeTextoToolStripMenuItem,
            this.calculadoraToolStripMenuItem});
            this.ContextMenuStrip1.Name = "ContextMenuStrip1";
            this.ContextMenuStrip1.Size = new System.Drawing.Size(180, 52);
            // 
            // editorDeTextoToolStripMenuItem
            // 
            this.editorDeTextoToolStripMenuItem.Name = "editorDeTextoToolStripMenuItem";
            this.editorDeTextoToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
            this.editorDeTextoToolStripMenuItem.Text = "Editor de Texto";
            // 
            // calculadoraToolStripMenuItem
            // 
            this.calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            this.calculadoraToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
            this.calculadoraToolStripMenuItem.Text = "Calculadora";
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 537);
            this.ContextMenuStrip = this.ContextMenuStrip1;
            this.Controls.Add(this.MnStpExercicios);
            this.IsMdiContainer = true;
            this.Name = "FrmPrincipal";
            this.Text = "Teste de Métodos";
            this.MnStpExercicios.ResumeLayout(false);
            this.MnStpExercicios.PerformLayout();
            this.ContextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnStpExercicios;
        private System.Windows.Forms.ToolStripMenuItem Exercício2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CopiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ColarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Exercício3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Exercício4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Exercício5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SairToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip ContextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editorDeTextoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem;
    }
}

