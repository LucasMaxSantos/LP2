﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Numero1) &&
    double.TryParse(txtNum2.Text, out Numero2))
            {
                Resultado = Numero1 - Numero2;
                txtNumero3.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Numero1) &&
            double.TryParse(txtNum2.Text, out Numero2))
            {
                Resultado = Numero1 * Numero2;
                txtNumero3.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos!");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Numero1) &&
            double.TryParse(txtNum2.Text, out Numero2))
            {
                if (Numero2 == 0)
                {
                    MessageBox.Show("Impossivel Divisão por Zero!");
                    txtNum2.Clear();
                    txtNum2.Focus();

                }
                else
                {
                    Resultado = Numero1 / Numero2;
                    txtNumero3.Text = Resultado.ToString();
                }
                
            }
            else
                MessageBox.Show("Números Inválidos!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtNumero3.Clear();

            txtNum1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Numero1) &&
                double.TryParse(txtNum2.Text, out Numero2))
            {
                Resultado = Numero1 + Numero2;
                txtNumero3.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos!");
        }
    }
}
