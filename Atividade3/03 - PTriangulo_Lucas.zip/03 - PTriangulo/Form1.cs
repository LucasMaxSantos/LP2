﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        Double LadoA, LadoB, LadoC;

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtLadoA.Clear();
            TxtLadoB.Clear();
            TxtLadoC.Clear();
            LblResposta.Text = "";
            TxtLadoA.Focus();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerifTriang_Click(object sender, EventArgs e)
        {
            if(Double.TryParse(TxtLadoA.Text, out LadoA) &&
               Double.TryParse(TxtLadoB.Text, out LadoB) &&
               Double.TryParse(TxtLadoC.Text, out LadoC))
              {
                if (LadoA < (LadoB + LadoC) && (LadoA > Math.Abs(LadoB - LadoC)) &&
                    LadoB < (LadoA + LadoC) && (LadoB > Math.Abs(LadoA - LadoC)) &&
                    LadoC < (LadoA + LadoB) && (LadoC > Math.Abs(LadoA - LadoB)))
                {
                    if (LadoA == LadoB && LadoB == LadoC)
                    {
                        LblResposta.Text = ("Triangulo Equilatero");
                    }
                    else
                    if (LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                    {
                        LblResposta.Text = ("Triangulo Isóceles");
                    }
                    else
                        LblResposta.Text = ("Triangulo Escaleno");
                }
                else 
                {
                    MessageBox.Show("Não é um triangulo");
                    TxtLadoA.Clear();
                    TxtLadoB.Clear();
                    TxtLadoC.Clear();
                    LblResposta.Text = "";
                    TxtLadoA.Focus();
                }
              }
            else
                MessageBox.Show("Preencha todos os campos Corretamente!");
        }
    }
}
