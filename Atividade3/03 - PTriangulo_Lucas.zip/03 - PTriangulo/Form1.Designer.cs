﻿
namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblLadoA = new System.Windows.Forms.Label();
            this.LblLadoB = new System.Windows.Forms.Label();
            this.LblLadoC = new System.Windows.Forms.Label();
            this.TxtLadoA = new System.Windows.Forms.TextBox();
            this.TxtLadoB = new System.Windows.Forms.TextBox();
            this.TxtLadoC = new System.Windows.Forms.TextBox();
            this.BtnVerifTriang = new System.Windows.Forms.Button();
            this.LblResposta = new System.Windows.Forms.Label();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblLadoA
            // 
            this.LblLadoA.AutoSize = true;
            this.LblLadoA.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.LblLadoA.Location = new System.Drawing.Point(468, 64);
            this.LblLadoA.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LblLadoA.Name = "LblLadoA";
            this.LblLadoA.Size = new System.Drawing.Size(27, 25);
            this.LblLadoA.TabIndex = 0;
            this.LblLadoA.Text = "A";
            // 
            // LblLadoB
            // 
            this.LblLadoB.AutoSize = true;
            this.LblLadoB.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LblLadoB.Location = new System.Drawing.Point(76, 579);
            this.LblLadoB.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LblLadoB.Name = "LblLadoB";
            this.LblLadoB.Size = new System.Drawing.Size(26, 25);
            this.LblLadoB.TabIndex = 1;
            this.LblLadoB.Text = "B";
            // 
            // LblLadoC
            // 
            this.LblLadoC.AutoSize = true;
            this.LblLadoC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LblLadoC.Location = new System.Drawing.Point(868, 579);
            this.LblLadoC.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LblLadoC.Name = "LblLadoC";
            this.LblLadoC.Size = new System.Drawing.Size(28, 25);
            this.LblLadoC.TabIndex = 2;
            this.LblLadoC.Text = "C";
            // 
            // TxtLadoA
            // 
            this.TxtLadoA.Location = new System.Drawing.Point(436, 90);
            this.TxtLadoA.Margin = new System.Windows.Forms.Padding(5);
            this.TxtLadoA.Name = "TxtLadoA";
            this.TxtLadoA.Size = new System.Drawing.Size(93, 30);
            this.TxtLadoA.TabIndex = 3;
            this.TxtLadoA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtLadoB
            // 
            this.TxtLadoB.Location = new System.Drawing.Point(46, 604);
            this.TxtLadoB.Margin = new System.Windows.Forms.Padding(5);
            this.TxtLadoB.Name = "TxtLadoB";
            this.TxtLadoB.Size = new System.Drawing.Size(93, 30);
            this.TxtLadoB.TabIndex = 4;
            this.TxtLadoB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtLadoC
            // 
            this.TxtLadoC.Location = new System.Drawing.Point(841, 604);
            this.TxtLadoC.Margin = new System.Windows.Forms.Padding(5);
            this.TxtLadoC.Name = "TxtLadoC";
            this.TxtLadoC.Size = new System.Drawing.Size(93, 30);
            this.TxtLadoC.TabIndex = 6;
            this.TxtLadoC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnVerifTriang
            // 
            this.BtnVerifTriang.Location = new System.Drawing.Point(291, 685);
            this.BtnVerifTriang.Name = "BtnVerifTriang";
            this.BtnVerifTriang.Size = new System.Drawing.Size(104, 45);
            this.BtnVerifTriang.TabIndex = 7;
            this.BtnVerifTriang.Text = "Verificar";
            this.BtnVerifTriang.UseVisualStyleBackColor = true;
            this.BtnVerifTriang.Click += new System.EventHandler(this.BtnVerifTriang_Click);
            // 
            // LblResposta
            // 
            this.LblResposta.AutoSize = true;
            this.LblResposta.BackColor = System.Drawing.Color.Gainsboro;
            this.LblResposta.ForeColor = System.Drawing.Color.Red;
            this.LblResposta.Location = new System.Drawing.Point(406, 410);
            this.LblResposta.Name = "LblResposta";
            this.LblResposta.Size = new System.Drawing.Size(0, 25);
            this.LblResposta.TabIndex = 8;
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(438, 685);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(104, 45);
            this.BtnLimpar.TabIndex = 9;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(577, 685);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(104, 45);
            this.BtnSair.TabIndex = 10;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PTriangulo.Properties.Resources.fundo_geometrico_realista_branco_com_triangulo_1045_126;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(974, 806);
            this.ControlBox = false;
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.LblResposta);
            this.Controls.Add(this.BtnVerifTriang);
            this.Controls.Add(this.TxtLadoC);
            this.Controls.Add(this.TxtLadoB);
            this.Controls.Add(this.TxtLadoA);
            this.Controls.Add(this.LblLadoC);
            this.Controls.Add(this.LblLadoB);
            this.Controls.Add(this.LblLadoA);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "PTriângullo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblLadoA;
        private System.Windows.Forms.Label LblLadoB;
        private System.Windows.Forms.Label LblLadoC;
        private System.Windows.Forms.TextBox TxtLadoA;
        private System.Windows.Forms.TextBox TxtLadoB;
        private System.Windows.Forms.TextBox TxtLadoC;
        private System.Windows.Forms.Button BtnVerifTriang;
        private System.Windows.Forms.Label LblResposta;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
    }
}

