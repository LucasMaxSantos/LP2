﻿
namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNome = new System.Windows.Forms.Label();
            this.LblSalBruto = new System.Windows.Forms.Label();
            this.LblNumFilhos = new System.Windows.Forms.Label();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.MskbxSalariobruto = new System.Windows.Forms.MaskedTextBox();
            this.CbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.GbxSexo = new System.Windows.Forms.GroupBox();
            this.RbtnMasc = new System.Windows.Forms.RadioButton();
            this.RbtnFem = new System.Windows.Forms.RadioButton();
            this.GbxCasado = new System.Windows.Forms.GroupBox();
            this.CkbxCasado = new System.Windows.Forms.CheckBox();
            this.BtnVerifica = new System.Windows.Forms.Button();
            this.GbxResultado = new System.Windows.Forms.GroupBox();
            this.LblMensagem = new System.Windows.Forms.Label();
            this.TxtDescIR = new System.Windows.Forms.TextBox();
            this.TxtAliqINSS = new System.Windows.Forms.TextBox();
            this.TxtDesINSS = new System.Windows.Forms.TextBox();
            this.LblAliqINSS = new System.Windows.Forms.Label();
            this.LblDescIR = new System.Windows.Forms.Label();
            this.LblAliqIR = new System.Windows.Forms.Label();
            this.LblDescINSS = new System.Windows.Forms.Label();
            this.LblSalFamilia = new System.Windows.Forms.Label();
            this.TxtSalLiquido = new System.Windows.Forms.TextBox();
            this.LblSalLiquido = new System.Windows.Forms.Label();
            this.TxtSalFamilia = new System.Windows.Forms.TextBox();
            this.TxtAliqIR = new System.Windows.Forms.TextBox();
            this.GbxSexo.SuspendLayout();
            this.GbxCasado.SuspendLayout();
            this.GbxResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(56, 30);
            this.LblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(197, 20);
            this.LblNome.TabIndex = 0;
            this.LblNome.Text = "Nome do Colaborador:";
            // 
            // LblSalBruto
            // 
            this.LblSalBruto.AutoSize = true;
            this.LblSalBruto.Location = new System.Drawing.Point(56, 86);
            this.LblSalBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblSalBruto.Name = "LblSalBruto";
            this.LblSalBruto.Size = new System.Drawing.Size(126, 20);
            this.LblSalBruto.TabIndex = 1;
            this.LblSalBruto.Text = "Salário Bruto:";
            // 
            // LblNumFilhos
            // 
            this.LblNumFilhos.AutoSize = true;
            this.LblNumFilhos.Location = new System.Drawing.Point(56, 141);
            this.LblNumFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblNumFilhos.Name = "LblNumFilhos";
            this.LblNumFilhos.Size = new System.Drawing.Size(163, 20);
            this.LblNumFilhos.TabIndex = 2;
            this.LblNumFilhos.Text = "Número de Filhos:";
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(290, 24);
            this.TxtNome.Margin = new System.Windows.Forms.Padding(4);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(441, 27);
            this.TxtNome.TabIndex = 3;
            this.TxtNome.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // MskbxSalariobruto
            // 
            this.MskbxSalariobruto.Location = new System.Drawing.Point(290, 86);
            this.MskbxSalariobruto.Margin = new System.Windows.Forms.Padding(4);
            this.MskbxSalariobruto.Mask = "000000.00";
            this.MskbxSalariobruto.Name = "MskbxSalariobruto";
            this.MskbxSalariobruto.Size = new System.Drawing.Size(441, 27);
            this.MskbxSalariobruto.TabIndex = 4;
            this.MskbxSalariobruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // CbxNumFilhos
            // 
            this.CbxNumFilhos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxNumFilhos.FormattingEnabled = true;
            this.CbxNumFilhos.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.CbxNumFilhos.Location = new System.Drawing.Point(580, 141);
            this.CbxNumFilhos.Margin = new System.Windows.Forms.Padding(4);
            this.CbxNumFilhos.Name = "CbxNumFilhos";
            this.CbxNumFilhos.Size = new System.Drawing.Size(151, 28);
            this.CbxNumFilhos.TabIndex = 5;
            // 
            // GbxSexo
            // 
            this.GbxSexo.Controls.Add(this.RbtnMasc);
            this.GbxSexo.Controls.Add(this.RbtnFem);
            this.GbxSexo.Location = new System.Drawing.Point(813, 24);
            this.GbxSexo.Margin = new System.Windows.Forms.Padding(4);
            this.GbxSexo.Name = "GbxSexo";
            this.GbxSexo.Padding = new System.Windows.Forms.Padding(4);
            this.GbxSexo.Size = new System.Drawing.Size(275, 78);
            this.GbxSexo.TabIndex = 6;
            this.GbxSexo.TabStop = false;
            this.GbxSexo.Text = "Sexo";
            // 
            // RbtnMasc
            // 
            this.RbtnMasc.AutoSize = true;
            this.RbtnMasc.Checked = true;
            this.RbtnMasc.Location = new System.Drawing.Point(139, 32);
            this.RbtnMasc.Margin = new System.Windows.Forms.Padding(4);
            this.RbtnMasc.Name = "RbtnMasc";
            this.RbtnMasc.Size = new System.Drawing.Size(45, 24);
            this.RbtnMasc.TabIndex = 9;
            this.RbtnMasc.TabStop = true;
            this.RbtnMasc.Text = "M";
            this.RbtnMasc.UseVisualStyleBackColor = true;
            // 
            // RbtnFem
            // 
            this.RbtnFem.AutoSize = true;
            this.RbtnFem.Location = new System.Drawing.Point(36, 32);
            this.RbtnFem.Margin = new System.Windows.Forms.Padding(4);
            this.RbtnFem.Name = "RbtnFem";
            this.RbtnFem.Size = new System.Drawing.Size(41, 24);
            this.RbtnFem.TabIndex = 8;
            this.RbtnFem.Text = "F";
            this.RbtnFem.UseVisualStyleBackColor = true;
            // 
            // GbxCasado
            // 
            this.GbxCasado.Controls.Add(this.CkbxCasado);
            this.GbxCasado.Location = new System.Drawing.Point(813, 106);
            this.GbxCasado.Margin = new System.Windows.Forms.Padding(4);
            this.GbxCasado.Name = "GbxCasado";
            this.GbxCasado.Padding = new System.Windows.Forms.Padding(4);
            this.GbxCasado.Size = new System.Drawing.Size(275, 70);
            this.GbxCasado.TabIndex = 7;
            this.GbxCasado.TabStop = false;
            this.GbxCasado.Text = "Estado Civil";
            // 
            // CkbxCasado
            // 
            this.CkbxCasado.AutoSize = true;
            this.CkbxCasado.Location = new System.Drawing.Point(15, 29);
            this.CkbxCasado.Margin = new System.Windows.Forms.Padding(4);
            this.CkbxCasado.Name = "CkbxCasado";
            this.CkbxCasado.Size = new System.Drawing.Size(94, 24);
            this.CkbxCasado.TabIndex = 8;
            this.CkbxCasado.Text = "Casado";
            this.CkbxCasado.UseVisualStyleBackColor = true;
            // 
            // BtnVerifica
            // 
            this.BtnVerifica.Location = new System.Drawing.Point(407, 239);
            this.BtnVerifica.Margin = new System.Windows.Forms.Padding(4);
            this.BtnVerifica.Name = "BtnVerifica";
            this.BtnVerifica.Size = new System.Drawing.Size(293, 52);
            this.BtnVerifica.TabIndex = 8;
            this.BtnVerifica.Text = "Verificar Descontos";
            this.BtnVerifica.UseVisualStyleBackColor = true;
            this.BtnVerifica.Click += new System.EventHandler(this.BtnVerifica_Click);
            // 
            // GbxResultado
            // 
            this.GbxResultado.Controls.Add(this.LblMensagem);
            this.GbxResultado.Controls.Add(this.TxtDescIR);
            this.GbxResultado.Controls.Add(this.TxtAliqINSS);
            this.GbxResultado.Controls.Add(this.TxtDesINSS);
            this.GbxResultado.Controls.Add(this.LblAliqINSS);
            this.GbxResultado.Controls.Add(this.LblDescIR);
            this.GbxResultado.Controls.Add(this.LblAliqIR);
            this.GbxResultado.Controls.Add(this.LblDescINSS);
            this.GbxResultado.Controls.Add(this.LblSalFamilia);
            this.GbxResultado.Controls.Add(this.TxtSalLiquido);
            this.GbxResultado.Controls.Add(this.LblSalLiquido);
            this.GbxResultado.Controls.Add(this.TxtSalFamilia);
            this.GbxResultado.Controls.Add(this.TxtAliqIR);
            this.GbxResultado.Location = new System.Drawing.Point(60, 352);
            this.GbxResultado.Name = "GbxResultado";
            this.GbxResultado.Size = new System.Drawing.Size(1028, 319);
            this.GbxResultado.TabIndex = 9;
            this.GbxResultado.TabStop = false;
            // 
            // LblMensagem
            // 
            this.LblMensagem.AutoSize = true;
            this.LblMensagem.Location = new System.Drawing.Point(60, 34);
            this.LblMensagem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblMensagem.Name = "LblMensagem";
            this.LblMensagem.Size = new System.Drawing.Size(99, 20);
            this.LblMensagem.TabIndex = 60;
            this.LblMensagem.Text = "Mensagem";
            this.LblMensagem.Visible = false;
            // 
            // TxtDescIR
            // 
            this.TxtDescIR.Enabled = false;
            this.TxtDescIR.ForeColor = System.Drawing.Color.Red;
            this.TxtDescIR.Location = new System.Drawing.Point(790, 159);
            this.TxtDescIR.Margin = new System.Windows.Forms.Padding(4);
            this.TxtDescIR.Name = "TxtDescIR";
            this.TxtDescIR.Size = new System.Drawing.Size(136, 27);
            this.TxtDescIR.TabIndex = 59;
            this.TxtDescIR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtDescIR.Visible = false;
            // 
            // TxtAliqINSS
            // 
            this.TxtAliqINSS.Enabled = false;
            this.TxtAliqINSS.Location = new System.Drawing.Point(225, 110);
            this.TxtAliqINSS.Margin = new System.Windows.Forms.Padding(4);
            this.TxtAliqINSS.Name = "TxtAliqINSS";
            this.TxtAliqINSS.Size = new System.Drawing.Size(136, 27);
            this.TxtAliqINSS.TabIndex = 52;
            this.TxtAliqINSS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtAliqINSS.Visible = false;
            // 
            // TxtDesINSS
            // 
            this.TxtDesINSS.Enabled = false;
            this.TxtDesINSS.ForeColor = System.Drawing.SystemColors.WindowText;
            this.TxtDesINSS.Location = new System.Drawing.Point(790, 110);
            this.TxtDesINSS.Margin = new System.Windows.Forms.Padding(4);
            this.TxtDesINSS.Name = "TxtDesINSS";
            this.TxtDesINSS.Size = new System.Drawing.Size(136, 27);
            this.TxtDesINSS.TabIndex = 58;
            this.TxtDesINSS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtDesINSS.Visible = false;
            // 
            // LblAliqINSS
            // 
            this.LblAliqINSS.AutoSize = true;
            this.LblAliqINSS.Location = new System.Drawing.Point(71, 110);
            this.LblAliqINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblAliqINSS.Name = "LblAliqINSS";
            this.LblAliqINSS.Size = new System.Drawing.Size(125, 20);
            this.LblAliqINSS.TabIndex = 48;
            this.LblAliqINSS.Text = "Aliquota INSS";
            this.LblAliqINSS.Visible = false;
            // 
            // LblDescIR
            // 
            this.LblDescIR.AutoSize = true;
            this.LblDescIR.Location = new System.Drawing.Point(642, 165);
            this.LblDescIR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblDescIR.Name = "LblDescIR";
            this.LblDescIR.Size = new System.Drawing.Size(136, 20);
            this.LblDescIR.TabIndex = 57;
            this.LblDescIR.Text = "Desconto IRPF";
            this.LblDescIR.Visible = false;
            // 
            // LblAliqIR
            // 
            this.LblAliqIR.AutoSize = true;
            this.LblAliqIR.Location = new System.Drawing.Point(71, 165);
            this.LblAliqIR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblAliqIR.Name = "LblAliqIR";
            this.LblAliqIR.Size = new System.Drawing.Size(124, 20);
            this.LblAliqIR.TabIndex = 49;
            this.LblAliqIR.Text = "Aliquota IRPF";
            this.LblAliqIR.Visible = false;
            // 
            // LblDescINSS
            // 
            this.LblDescINSS.AutoSize = true;
            this.LblDescINSS.Location = new System.Drawing.Point(642, 110);
            this.LblDescINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblDescINSS.Name = "LblDescINSS";
            this.LblDescINSS.Size = new System.Drawing.Size(137, 20);
            this.LblDescINSS.TabIndex = 56;
            this.LblDescINSS.Text = "Desconto INSS";
            this.LblDescINSS.Visible = false;
            // 
            // LblSalFamilia
            // 
            this.LblSalFamilia.AutoSize = true;
            this.LblSalFamilia.Location = new System.Drawing.Point(71, 223);
            this.LblSalFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblSalFamilia.Name = "LblSalFamilia";
            this.LblSalFamilia.Size = new System.Drawing.Size(135, 20);
            this.LblSalFamilia.TabIndex = 50;
            this.LblSalFamilia.Text = "Salário Família";
            this.LblSalFamilia.Visible = false;
            // 
            // TxtSalLiquido
            // 
            this.TxtSalLiquido.Enabled = false;
            this.TxtSalLiquido.Location = new System.Drawing.Point(225, 278);
            this.TxtSalLiquido.Margin = new System.Windows.Forms.Padding(4);
            this.TxtSalLiquido.Name = "TxtSalLiquido";
            this.TxtSalLiquido.Size = new System.Drawing.Size(136, 27);
            this.TxtSalLiquido.TabIndex = 55;
            this.TxtSalLiquido.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtSalLiquido.Visible = false;
            // 
            // LblSalLiquido
            // 
            this.LblSalLiquido.AutoSize = true;
            this.LblSalLiquido.Location = new System.Drawing.Point(71, 284);
            this.LblSalLiquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblSalLiquido.Name = "LblSalLiquido";
            this.LblSalLiquido.Size = new System.Drawing.Size(135, 20);
            this.LblSalLiquido.TabIndex = 51;
            this.LblSalLiquido.Text = "Salário Líquido";
            this.LblSalLiquido.Visible = false;
            // 
            // TxtSalFamilia
            // 
            this.TxtSalFamilia.Enabled = false;
            this.TxtSalFamilia.Location = new System.Drawing.Point(225, 223);
            this.TxtSalFamilia.Margin = new System.Windows.Forms.Padding(4);
            this.TxtSalFamilia.Name = "TxtSalFamilia";
            this.TxtSalFamilia.Size = new System.Drawing.Size(136, 27);
            this.TxtSalFamilia.TabIndex = 54;
            this.TxtSalFamilia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtSalFamilia.Visible = false;
            // 
            // TxtAliqIR
            // 
            this.TxtAliqIR.Enabled = false;
            this.TxtAliqIR.Location = new System.Drawing.Point(225, 165);
            this.TxtAliqIR.Margin = new System.Windows.Forms.Padding(4);
            this.TxtAliqIR.Name = "TxtAliqIR";
            this.TxtAliqIR.Size = new System.Drawing.Size(136, 27);
            this.TxtAliqIR.TabIndex = 53;
            this.TxtAliqIR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtAliqIR.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1140, 708);
            this.Controls.Add(this.GbxResultado);
            this.Controls.Add(this.BtnVerifica);
            this.Controls.Add(this.GbxCasado);
            this.Controls.Add(this.GbxSexo);
            this.Controls.Add(this.CbxNumFilhos);
            this.Controls.Add(this.MskbxSalariobruto);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.LblNumFilhos);
            this.Controls.Add(this.LblSalBruto);
            this.Controls.Add(this.LblNome);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PSalário";
            this.GbxSexo.ResumeLayout(false);
            this.GbxSexo.PerformLayout();
            this.GbxCasado.ResumeLayout(false);
            this.GbxCasado.PerformLayout();
            this.GbxResultado.ResumeLayout(false);
            this.GbxResultado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblSalBruto;
        private System.Windows.Forms.Label LblNumFilhos;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.MaskedTextBox MskbxSalariobruto;
        private System.Windows.Forms.ComboBox CbxNumFilhos;
        private System.Windows.Forms.GroupBox GbxSexo;
        private System.Windows.Forms.RadioButton RbtnMasc;
        private System.Windows.Forms.RadioButton RbtnFem;
        private System.Windows.Forms.GroupBox GbxCasado;
        private System.Windows.Forms.Button BtnVerifica;
        private System.Windows.Forms.CheckBox CkbxCasado;
        private System.Windows.Forms.GroupBox GbxResultado;
        private System.Windows.Forms.Label LblMensagem;
        private System.Windows.Forms.TextBox TxtDescIR;
        private System.Windows.Forms.TextBox TxtAliqINSS;
        private System.Windows.Forms.TextBox TxtDesINSS;
        private System.Windows.Forms.Label LblAliqINSS;
        private System.Windows.Forms.Label LblDescIR;
        private System.Windows.Forms.Label LblAliqIR;
        private System.Windows.Forms.Label LblDescINSS;
        private System.Windows.Forms.Label LblSalFamilia;
        private System.Windows.Forms.TextBox TxtSalLiquido;
        private System.Windows.Forms.Label LblSalLiquido;
        private System.Windows.Forms.TextBox TxtSalFamilia;
        private System.Windows.Forms.TextBox TxtAliqIR;
    }
}

