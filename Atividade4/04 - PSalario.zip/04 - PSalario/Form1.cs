﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CbxNumFilhos.SelectedIndex = 0;
        }

        private void BtnVerifica_Click(object sender, EventArgs e)
        {

            double DescINSS = 0;
            double DescIR = 0;
            double SalFamilia = 0;
            double SalLiquido = 0;
            double SalBruto = 0;
            int    Numfilhos = 0;

            if ((TxtNome.Text == "") || (TxtNome.Text.Length < 8))
                MessageBox.Show("Nome inválido!");

            else if (double.TryParse(MskbxSalariobruto.Text, out SalBruto))
            {
                //Muda Status para Visível

                LblMensagem.Visible = true;
                LblAliqINSS.Visible = true;
                LblAliqIR.Visible = true;
                LblSalFamilia.Visible = true;
                LblSalLiquido.Visible = true;
                LblDescINSS.Visible = true;
                LblDescIR.Visible = true;
                TxtAliqINSS.Visible = true;
                TxtAliqIR.Visible = true;
                TxtSalFamilia.Visible = true;
                TxtSalLiquido.Visible = true;
                TxtDesINSS.Visible = true;
                TxtDescIR.Visible = true;

                //Calculo INSS
                if (SalBruto <= 800.47)
                {
                    TxtAliqINSS.Text = "7.65%";
                    DescINSS= 0.0765 * SalBruto;
                }
                else if (SalBruto <= 1050)
                {
                    TxtAliqINSS.Text = "8.65%";
                    DescINSS = 0.0865 * SalBruto;
                }
                else if (SalBruto <= 1477.77)
                {
                    TxtAliqINSS.Text = "9%";
                    DescINSS = 0.09 * SalBruto;
                }
                else if (SalBruto <= 2801.56)
                {
                    TxtAliqINSS.Text = "11%";
                    DescINSS = 0.11 * SalBruto;
                }
                else if (SalBruto > 2801.56)
                {
                    TxtAliqINSS.Text = "308,17";
                    DescINSS = 308.17;
                }
                //Exibir na TxtDescINSS
                TxtDesINSS.Text = DescINSS.ToString("N2");

                //Calculo IR
                if (SalBruto <= 1257.12)
                    TxtAliqIR.Text = "Isento";
                else if (SalBruto <= 2512.08)
                {
                    TxtAliqIR.Text = "15%";
                    DescIR = 0.15 * SalBruto;
                }
                else if (SalBruto > 2512.08)
                {
                    TxtAliqIR.Text = "27,5%";
                    DescIR = 0.275 * SalBruto;
                }
                //Exibir na TxtDescIR
                TxtDescIR.Text = DescIR.ToString("N2");

                //Calculo Salário Família

                int.TryParse(CbxNumFilhos.Text, out Numfilhos);
                if (SalBruto <= 435.52)
                    SalFamilia  = 22.33 * Numfilhos;
                else if (SalBruto <= 654.61)
                    SalFamilia = 15.74 * Numfilhos;

                //Exibir Salário Família
                TxtSalFamilia.Text = SalFamilia.ToString("N2");

                //Calculo Salário Líquido

                SalLiquido = SalBruto - DescINSS - DescIR + SalFamilia;
                TxtSalLiquido.Text = SalLiquido.ToString("N2");

                //Mensagem LblMensagem

                LblMensagem.Text = "Os Descontos do Salário ";

                if (RbtnMasc.Checked)
                    LblMensagem.Text = LblMensagem.Text + "Do Sr. " + TxtNome.Text;
                else
                    LblMensagem.Text = LblMensagem.Text + "Da Sra. " + TxtNome.Text;

                LblMensagem.Text = LblMensagem.Text + " Que é ";

                if (CkbxCasado.Checked)
                    LblMensagem.Text = LblMensagem.Text + "Casado(a) ";
                else
                    LblMensagem.Text = LblMensagem.Text + "Solteiro(a) ";

                if(Numfilhos>0)
                    LblMensagem.Text = LblMensagem.Text + "e que tem " + Numfilhos + " filho(s) ";

                LblMensagem.Text = LblMensagem.Text + "são: ";


            }
            else
                MessageBox.Show("Salário Bruto inválido!");



        }
    }
}
