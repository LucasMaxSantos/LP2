﻿
namespace Pclasses
{
    partial class FrmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtNumHoras = new System.Windows.Forms.TextBox();
            this.TxtSalario = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.LblData = new System.Windows.Forms.Label();
            this.LblSalario = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblMatricula = new System.Windows.Forms.Label();
            this.TxtData = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtFaltas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BtnHorista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtNumHoras
            // 
            this.TxtNumHoras.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumHoras.Location = new System.Drawing.Point(295, 174);
            this.TxtNumHoras.Name = "TxtNumHoras";
            this.TxtNumHoras.Size = new System.Drawing.Size(120, 24);
            this.TxtNumHoras.TabIndex = 15;
            this.TxtNumHoras.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtSalario
            // 
            this.TxtSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSalario.Location = new System.Drawing.Point(295, 124);
            this.TxtSalario.Name = "TxtSalario";
            this.TxtSalario.Size = new System.Drawing.Size(120, 24);
            this.TxtSalario.TabIndex = 14;
            this.TxtSalario.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtNome
            // 
            this.TxtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNome.Location = new System.Drawing.Point(295, 79);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(312, 24);
            this.TxtNome.TabIndex = 13;
            this.TxtNome.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMatricula.Location = new System.Drawing.Point(295, 35);
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(120, 24);
            this.TxtMatricula.TabIndex = 12;
            this.TxtMatricula.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblData
            // 
            this.LblData.AutoSize = true;
            this.LblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblData.Location = new System.Drawing.Point(62, 174);
            this.LblData.Name = "LblData";
            this.LblData.Size = new System.Drawing.Size(127, 18);
            this.LblData.TabIndex = 11;
            this.LblData.Text = "Número de Horas";
            // 
            // LblSalario
            // 
            this.LblSalario.AutoSize = true;
            this.LblSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSalario.Location = new System.Drawing.Point(62, 127);
            this.LblSalario.Name = "LblSalario";
            this.LblSalario.Size = new System.Drawing.Size(125, 18);
            this.LblSalario.TabIndex = 10;
            this.LblSalario.Text = "Salário por Horas";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNome.Location = new System.Drawing.Point(62, 79);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(49, 18);
            this.LblNome.TabIndex = 9;
            this.LblNome.Text = "Nome";
            // 
            // LblMatricula
            // 
            this.LblMatricula.AutoSize = true;
            this.LblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMatricula.Location = new System.Drawing.Point(62, 35);
            this.LblMatricula.Name = "LblMatricula";
            this.LblMatricula.Size = new System.Drawing.Size(68, 18);
            this.LblMatricula.TabIndex = 8;
            this.LblMatricula.Text = "Matrícula";
            // 
            // TxtData
            // 
            this.TxtData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtData.Location = new System.Drawing.Point(295, 217);
            this.TxtData.Name = "TxtData";
            this.TxtData.Size = new System.Drawing.Size(209, 24);
            this.TxtData.TabIndex = 17;
            this.TxtData.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 217);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 18);
            this.label1.TabIndex = 16;
            this.label1.Text = "Data de Entrada na Empresa";
            // 
            // TxtFaltas
            // 
            this.TxtFaltas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFaltas.Location = new System.Drawing.Point(295, 264);
            this.TxtFaltas.Name = "TxtFaltas";
            this.TxtFaltas.Size = new System.Drawing.Size(120, 24);
            this.TxtFaltas.TabIndex = 19;
            this.TxtFaltas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(62, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 18);
            this.label2.TabIndex = 18;
            this.label2.Text = "Dias de Faltas";
            // 
            // BtnHorista
            // 
            this.BtnHorista.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHorista.Location = new System.Drawing.Point(246, 334);
            this.BtnHorista.Name = "BtnHorista";
            this.BtnHorista.Size = new System.Drawing.Size(258, 78);
            this.BtnHorista.TabIndex = 20;
            this.BtnHorista.Text = "Instanciar Horista";
            this.BtnHorista.UseVisualStyleBackColor = true;
            this.BtnHorista.Click += new System.EventHandler(this.BtnHorista_Click);
            // 
            // FrmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 450);
            this.Controls.Add(this.BtnHorista);
            this.Controls.Add(this.TxtFaltas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TxtData);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtNumHoras);
            this.Controls.Add(this.TxtSalario);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtMatricula);
            this.Controls.Add(this.LblData);
            this.Controls.Add(this.LblSalario);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.LblMatricula);
            this.Name = "FrmHorista";
            this.Text = "frmHorsita";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtNumHoras;
        private System.Windows.Forms.TextBox TxtSalario;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.Label LblData;
        private System.Windows.Forms.Label LblSalario;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblMatricula;
        private System.Windows.Forms.TextBox TxtData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtFaltas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BtnHorista;
    }
}