﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void BtnHorista_Click(object sender, EventArgs e)
        {

            //instanciar o objeto  da classe horista
            Horista objHorista = new Horista();
            
            //set atribui valores para o objeto
            objHorista.NomeEmpregado = TxtNome.Text;
            objHorista.Matricula = Convert.ToInt32(TxtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(TxtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(TxtNumHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(TxtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(TxtFaltas.Text);

            //get - imprimie os valores do objeto

            MessageBox.Show("Nome: " + objHorista.NomeEmpregado + "\n" + "Matrícula: " + objHorista.Matricula
                    + "\n" + "Tempo de Trabalho (dias): " + objHorista.TempoTrabalho().ToString() + "\n" + 
                    "Salário: " + objHorista.SalarioBruto().ToString("n2"));


        }
    }
}
