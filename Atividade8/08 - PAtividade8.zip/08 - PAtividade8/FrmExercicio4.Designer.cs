﻿
namespace PAtividade8
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmExercicio4));
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.RbtnA = new System.Windows.Forms.RadioButton();
            this.RbtnB = new System.Windows.Forms.RadioButton();
            this.RbtnC = new System.Windows.Forms.RadioButton();
            this.RbtnD = new System.Windows.Forms.RadioButton();
            this.BtnVerifica = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(108, 21);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(569, 232);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // RbtnA
            // 
            this.RbtnA.AutoSize = true;
            this.RbtnA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbtnA.Location = new System.Drawing.Point(108, 278);
            this.RbtnA.Name = "RbtnA";
            this.RbtnA.Size = new System.Drawing.Size(73, 24);
            this.RbtnA.TabIndex = 5;
            this.RbtnA.TabStop = true;
            this.RbtnA.Text = "a) 51";
            this.RbtnA.UseVisualStyleBackColor = true;
            // 
            // RbtnB
            // 
            this.RbtnB.AutoSize = true;
            this.RbtnB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbtnB.Location = new System.Drawing.Point(262, 278);
            this.RbtnB.Name = "RbtnB";
            this.RbtnB.Size = new System.Drawing.Size(73, 24);
            this.RbtnB.TabIndex = 6;
            this.RbtnB.TabStop = true;
            this.RbtnB.Text = "b) 50";
            this.RbtnB.UseVisualStyleBackColor = true;
            // 
            // RbtnC
            // 
            this.RbtnC.AutoSize = true;
            this.RbtnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbtnC.Location = new System.Drawing.Point(437, 278);
            this.RbtnC.Name = "RbtnC";
            this.RbtnC.Size = new System.Drawing.Size(67, 24);
            this.RbtnC.TabIndex = 7;
            this.RbtnC.TabStop = true;
            this.RbtnC.Text = "c)46";
            this.RbtnC.UseVisualStyleBackColor = true;
            // 
            // RbtnD
            // 
            this.RbtnD.AutoSize = true;
            this.RbtnD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbtnD.Location = new System.Drawing.Point(604, 278);
            this.RbtnD.Name = "RbtnD";
            this.RbtnD.Size = new System.Drawing.Size(73, 24);
            this.RbtnD.TabIndex = 8;
            this.RbtnD.TabStop = true;
            this.RbtnD.Text = "d) 48";
            this.RbtnD.UseVisualStyleBackColor = true;
            // 
            // BtnVerifica
            // 
            this.BtnVerifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVerifica.Location = new System.Drawing.Point(291, 342);
            this.BtnVerifica.Name = "BtnVerifica";
            this.BtnVerifica.Size = new System.Drawing.Size(186, 59);
            this.BtnVerifica.TabIndex = 9;
            this.BtnVerifica.Text = "Verificar Resposta";
            this.BtnVerifica.UseVisualStyleBackColor = true;
            this.BtnVerifica.Click += new System.EventHandler(this.BtnVerifica_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnVerifica);
            this.Controls.Add(this.RbtnD);
            this.Controls.Add(this.RbtnC);
            this.Controls.Add(this.RbtnB);
            this.Controls.Add(this.RbtnA);
            this.Controls.Add(this.richTextBox1);
            this.Name = "FrmExercicio4";
            this.Text = "Teste de Mesa";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RadioButton RbtnA;
        private System.Windows.Forms.RadioButton RbtnB;
        private System.Windows.Forms.RadioButton RbtnC;
        private System.Windows.Forms.RadioButton RbtnD;
        private System.Windows.Forms.Button BtnVerifica;
    }
}