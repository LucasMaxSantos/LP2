﻿
namespace PAtividade8
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.MnStpMenu = new System.Windows.Forms.MenuStrip();
            this.TlStpExercicio1 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicio2 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicio4 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicio5 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicio6 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpExercicio7 = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStpSair = new System.Windows.Forms.ToolStripMenuItem();
            this.MnStpMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnStpMenu
            // 
            this.MnStpMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.MnStpMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TlStpExercicio1,
            this.TlStpExercicio2,
            this.TlStpExercicio4,
            this.TlStpExercicio5,
            this.TlStpExercicio6,
            this.TlStpExercicio7,
            this.TlStpSair});
            this.MnStpMenu.Location = new System.Drawing.Point(0, 0);
            this.MnStpMenu.Name = "MnStpMenu";
            this.MnStpMenu.Size = new System.Drawing.Size(800, 28);
            this.MnStpMenu.TabIndex = 0;
            this.MnStpMenu.Text = "menuStrip1";
            // 
            // TlStpExercicio1
            // 
            this.TlStpExercicio1.Name = "TlStpExercicio1";
            this.TlStpExercicio1.Size = new System.Drawing.Size(118, 24);
            this.TlStpExercicio1.Text = "Exercício 1 e 2";
            this.TlStpExercicio1.Click += new System.EventHandler(this.TlStpExercicio1_Click);
            // 
            // TlStpExercicio2
            // 
            this.TlStpExercicio2.Name = "TlStpExercicio2";
            this.TlStpExercicio2.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio2.Text = "Exercício 3";
            this.TlStpExercicio2.Click += new System.EventHandler(this.TlStpExercicio2_Click);
            // 
            // TlStpExercicio4
            // 
            this.TlStpExercicio4.Name = "TlStpExercicio4";
            this.TlStpExercicio4.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio4.Text = "Exercício 4";
            this.TlStpExercicio4.Click += new System.EventHandler(this.TlStpExercicio4_Click);
            // 
            // TlStpExercicio5
            // 
            this.TlStpExercicio5.Name = "TlStpExercicio5";
            this.TlStpExercicio5.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio5.Text = "Exercício 5";
            this.TlStpExercicio5.Click += new System.EventHandler(this.TlStpExercicio5_Click);
            // 
            // TlStpExercicio6
            // 
            this.TlStpExercicio6.Name = "TlStpExercicio6";
            this.TlStpExercicio6.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio6.Text = "Exercício 6";
            this.TlStpExercicio6.Click += new System.EventHandler(this.TlStpExercicio6_Click);
            // 
            // TlStpExercicio7
            // 
            this.TlStpExercicio7.Name = "TlStpExercicio7";
            this.TlStpExercicio7.Size = new System.Drawing.Size(94, 24);
            this.TlStpExercicio7.Text = "Exercício 7";
            this.TlStpExercicio7.Click += new System.EventHandler(this.TlStpExercicio7_Click);
            // 
            // TlStpSair
            // 
            this.TlStpSair.Name = "TlStpSair";
            this.TlStpSair.Size = new System.Drawing.Size(48, 24);
            this.TlStpSair.Text = "Sair";
            this.TlStpSair.Click += new System.EventHandler(this.TlStpSair_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MnStpMenu);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.MnStpMenu;
            this.Name = "FrmPrincipal";
            this.Text = "Atividade 8";
            this.MnStpMenu.ResumeLayout(false);
            this.MnStpMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnStpMenu;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio1;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio2;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio4;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio5;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio6;
        private System.Windows.Forms.ToolStripMenuItem TlStpExercicio7;
        private System.Windows.Forms.ToolStripMenuItem TlStpSair;
    }
}

