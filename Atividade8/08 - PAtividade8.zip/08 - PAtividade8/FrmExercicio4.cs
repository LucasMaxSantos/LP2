﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnVerifica_Click(object sender, EventArgs e)
        {
            if (RbtnA.Checked || RbtnB.Checked || RbtnC.Checked || RbtnD.Checked)
            {
                if (RbtnC.Checked)
                {
                    MessageBox.Show("Parabéns você acertou");
                }
                else
                    MessageBox.Show("Tente Novamente");
            }
            else
                MessageBox.Show("Escolha uma opção");
        }
    }
}
