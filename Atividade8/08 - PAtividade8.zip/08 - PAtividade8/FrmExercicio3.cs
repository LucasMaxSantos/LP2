﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnFaturamento_Click(object sender, EventArgs e)
        {
            int[] VetQtd = new int[10];
            double[] VetPreco = new double[10];
            string Aux = "";
            double Faturamento = 0;
            int i = 0;
            //recebe valor
            for (i = 0; i < VetPreco.Length; i++) // controla a posição
            {
                do
                {
                    Aux = Interaction.InputBox("Digite a quantidade do Produtos no Cod: " +
                        (i + 1).ToString(), "Entrada de Dados");

                    if (Aux == "")
                        break;

                    if (!int.TryParse(Aux, out VetQtd[i]))
                    {
                        MessageBox.Show("Número inválido!");
                    }
                } while (!(VetQtd[i] > 0));

                Aux = "";
                do
                {
                    Aux = Interaction.InputBox("Digite o Preço R$ do produtos de Cod: " +
                        (i + 1).ToString(), "Entrada de Dados");

                    if (Aux == "")
                        break;

                    if (!double.TryParse(Aux, out VetPreco[i]))
                    {
                        MessageBox.Show("Valor R$ inválido!");
                    }
                } while (!(VetPreco[i] > 0));
            }

            for (i = 0; i < VetQtd.Length; i++)
            {
                Faturamento += VetQtd[i] * VetPreco[i];
            }

            MessageBox.Show("O Faturamento Mensal é: " + Faturamento.ToString("C2"));
            
        }
    }
}
