﻿
namespace PAtividade8
{
    partial class FrmExercicio7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbxNomes = new System.Windows.Forms.ListBox();
            this.BtnExecutar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LbxNomes
            // 
            this.LbxNomes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbxNomes.FormattingEnabled = true;
            this.LbxNomes.ItemHeight = 18;
            this.LbxNomes.Location = new System.Drawing.Point(316, 27);
            this.LbxNomes.Name = "LbxNomes";
            this.LbxNomes.Size = new System.Drawing.Size(441, 364);
            this.LbxNomes.TabIndex = 3;
            // 
            // BtnExecutar
            // 
            this.BtnExecutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExecutar.Location = new System.Drawing.Point(43, 158);
            this.BtnExecutar.Name = "BtnExecutar";
            this.BtnExecutar.Size = new System.Drawing.Size(164, 75);
            this.BtnExecutar.TabIndex = 2;
            this.BtnExecutar.Text = "Executar";
            this.BtnExecutar.UseVisualStyleBackColor = true;
            this.BtnExecutar.Click += new System.EventHandler(this.BtnExecutar_Click);
            // 
            // FrmExercicio7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LbxNomes);
            this.Controls.Add(this.BtnExecutar);
            this.Name = "FrmExercicio7";
            this.Text = "Nomes Completos";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LbxNomes;
        private System.Windows.Forms.Button BtnExecutar;
    }
}