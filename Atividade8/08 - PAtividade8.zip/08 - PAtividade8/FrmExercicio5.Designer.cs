﻿
namespace PAtividade8
{
    partial class FrmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnExcluiAluno = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnExcluiAluno
            // 
            this.BtnExcluiAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExcluiAluno.Location = new System.Drawing.Point(295, 150);
            this.BtnExcluiAluno.Name = "BtnExcluiAluno";
            this.BtnExcluiAluno.Size = new System.Drawing.Size(218, 98);
            this.BtnExcluiAluno.TabIndex = 0;
            this.BtnExcluiAluno.Text = "Atualiza Lista de Nomes";
            this.BtnExcluiAluno.UseVisualStyleBackColor = true;
            this.BtnExcluiAluno.Click += new System.EventHandler(this.BtnExcluiAluno_Click);
            // 
            // FrmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnExcluiAluno);
            this.Name = "FrmExercicio5";
            this.Text = "Lista de Alunos";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnExcluiAluno;
    }
}