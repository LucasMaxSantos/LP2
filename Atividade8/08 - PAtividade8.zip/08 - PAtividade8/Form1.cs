﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void TlStpSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TlStpExercicio1_Click(object sender, EventArgs e)
        {
            FrmExercicio1_2 objFrm1 = new FrmExercicio1_2();
            objFrm1.MdiParent = this;
            objFrm1.WindowState = FormWindowState.Maximized;
            objFrm1.Show();
        }

        private void TlStpExercicio2_Click(object sender, EventArgs e)
        {
            FrmExercicio3 objFrm3 = new FrmExercicio3();
            objFrm3.MdiParent = this;
            objFrm3.WindowState = FormWindowState.Maximized;
            objFrm3.Show();
        }

        private void TlStpExercicio4_Click(object sender, EventArgs e)
        {
            FrmExercicio4 objFrm4 = new FrmExercicio4();
            objFrm4.MdiParent = this;
            objFrm4.WindowState = FormWindowState.Maximized;
            objFrm4.Show();
        }

        private void TlStpExercicio5_Click(object sender, EventArgs e)
        {
            FrmExercicio5 objFrm5 = new FrmExercicio5();
            objFrm5.MdiParent = this;
            objFrm5.WindowState = FormWindowState.Maximized;
            objFrm5.Show();
        }

        private void TlStpExercicio6_Click(object sender, EventArgs e)
        {
            FrmExercicio6 objFrm6 = new FrmExercicio6();
            objFrm6.MdiParent = this;
            objFrm6.WindowState = FormWindowState.Maximized;
            objFrm6.Show();
        }

        private void TlStpExercicio7_Click(object sender, EventArgs e)
        {
            FrmExercicio7 objFrm7 = new FrmExercicio7();
            objFrm7.MdiParent = this;
            objFrm7.WindowState = FormWindowState.Maximized;
            objFrm7.Show();
        }
    }
}
