﻿
namespace PAtividade8
{
    partial class FrmExercicio1_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnRecListaNum1 = new System.Windows.Forms.Button();
            this.BtnRecListaNum12 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnRecListaNum1
            // 
            this.BtnRecListaNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRecListaNum1.Location = new System.Drawing.Point(124, 163);
            this.BtnRecListaNum1.Name = "BtnRecListaNum1";
            this.BtnRecListaNum1.Size = new System.Drawing.Size(205, 118);
            this.BtnRecListaNum1.TabIndex = 0;
            this.BtnRecListaNum1.Text = "Recebe 20 Números";
            this.BtnRecListaNum1.UseVisualStyleBackColor = true;
            this.BtnRecListaNum1.Click += new System.EventHandler(this.BtnRecListaNum1_Click);
            // 
            // BtnRecListaNum12
            // 
            this.BtnRecListaNum12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRecListaNum12.Location = new System.Drawing.Point(460, 163);
            this.BtnRecListaNum12.Name = "BtnRecListaNum12";
            this.BtnRecListaNum12.Size = new System.Drawing.Size(205, 118);
            this.BtnRecListaNum12.TabIndex = 1;
            this.BtnRecListaNum12.Text = "Recebe 20 Números (Com Reverse)";
            this.BtnRecListaNum12.UseVisualStyleBackColor = true;
            this.BtnRecListaNum12.Click += new System.EventHandler(this.BtnRecListaNum12_Click);
            // 
            // FrmExercicio1_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnRecListaNum12);
            this.Controls.Add(this.BtnRecListaNum1);
            this.Name = "FrmExercicio1_2";
            this.Text = "Recebe 20 Números";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnRecListaNum1;
        private System.Windows.Forms.Button BtnRecListaNum12;
    }
}