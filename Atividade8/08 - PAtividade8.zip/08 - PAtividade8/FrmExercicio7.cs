﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class FrmExercicio7 : Form
    {
        public FrmExercicio7()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            string Auxiliar = "";
            int N = 0;
            int Comprimento;

            do
            {
                Auxiliar = Interaction.InputBox("Permitido apenas Número de 0 a 9" + "\n para 10 informe 0", 
                    "Informe o último digito do seu RA");

                
                if (Auxiliar == "")
                    break;

                if (!int.TryParse(Auxiliar, out N))
                {
                    MessageBox.Show("Número inválido!");
                    N = 11;

                }
            } while ((!(N >= 0)  || !(N < 10)));

            if (N == 0)
                N = 10;

            for (var i = 0; i < N; i++)
            {
                Comprimento = 0;
                Auxiliar = Interaction.InputBox("Digite o nome na posição: " +
                    (i + 1).ToString(), "Entrada de Dados");

                if (Auxiliar == "")
                    break;

                if (Auxiliar.Length < 8)
                {
                    MessageBox.Show("Nome inválido!");
                    i--;
                }
                else
                {
                    Comprimento = (Auxiliar.Replace(" ", "")).Length;
                    LbxNomes.Items.Add("O nome: " + Auxiliar + ":" + " tem " + Comprimento + " caracteres" + ("\n"));
                }

            }
            
        }
    }
}
