﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PVacina0030482023021
{
    public partial class FrmPrincipal : Form
    {

        public static SqlConnection conexao;//faz a conexão com o banco


        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            try // tratando o erro
            { 
                conexao = new SqlConnection("Data Source=LUCAS\\SQLEXPRESS;Initial Catalog=LP2;Integrated Security=True");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void TlSpMnItemSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TlSpMnItemCadVacina_Click(object sender, EventArgs e)
        {
            FrmVacina objFrm1 = new FrmVacina();
            objFrm1.MdiParent = this;
            objFrm1.WindowState = FormWindowState.Maximized;
            objFrm1.Show();
        }

        private void TlSpMnItemSobre_Click(object sender, EventArgs e)
        {
            FrmSobre objFrmSobre = new FrmSobre();
            objFrmSobre.MdiParent = this;
            objFrmSobre.WindowState = FormWindowState.Maximized;
            objFrmSobre.Show();
        }
    }
}
