﻿
namespace PVacina0030482023021
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.MnStpMenu = new System.Windows.Forms.MenuStrip();
            this.TlSpMnItemCadVacina = new System.Windows.Forms.ToolStripMenuItem();
            this.TlSpMnItemSobre = new System.Windows.Forms.ToolStripMenuItem();
            this.TlSpMnItemSair = new System.Windows.Forms.ToolStripMenuItem();
            this.MnStpMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnStpMenu
            // 
            this.MnStpMenu.BackColor = System.Drawing.Color.SkyBlue;
            this.MnStpMenu.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MnStpMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.MnStpMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TlSpMnItemCadVacina,
            this.TlSpMnItemSobre,
            this.TlSpMnItemSair});
            this.MnStpMenu.Location = new System.Drawing.Point(0, 0);
            this.MnStpMenu.Name = "MnStpMenu";
            this.MnStpMenu.Padding = new System.Windows.Forms.Padding(9, 2, 0, 2);
            this.MnStpMenu.Size = new System.Drawing.Size(1303, 28);
            this.MnStpMenu.TabIndex = 0;
            this.MnStpMenu.Text = "menuStrip1";
            // 
            // TlSpMnItemCadVacina
            // 
            this.TlSpMnItemCadVacina.Name = "TlSpMnItemCadVacina";
            this.TlSpMnItemCadVacina.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
            this.TlSpMnItemCadVacina.Size = new System.Drawing.Size(158, 24);
            this.TlSpMnItemCadVacina.Text = "Cadastro Vacinação";
            this.TlSpMnItemCadVacina.Click += new System.EventHandler(this.TlSpMnItemCadVacina_Click);
            // 
            // TlSpMnItemSobre
            // 
            this.TlSpMnItemSobre.Name = "TlSpMnItemSobre";
            this.TlSpMnItemSobre.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.TlSpMnItemSobre.Size = new System.Drawing.Size(63, 24);
            this.TlSpMnItemSobre.Text = "Sobre";
            this.TlSpMnItemSobre.Click += new System.EventHandler(this.TlSpMnItemSobre_Click);
            // 
            // TlSpMnItemSair
            // 
            this.TlSpMnItemSair.Name = "TlSpMnItemSair";
            this.TlSpMnItemSair.Size = new System.Drawing.Size(49, 24);
            this.TlSpMnItemSair.Text = "Sair";
            this.TlSpMnItemSair.Click += new System.EventHandler(this.TlSpMnItemSair_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1303, 633);
            this.Controls.Add(this.MnStpMenu);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.MnStpMenu;
            this.Name = "FrmPrincipal";
            this.Text = "PVacina 2021";
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.MnStpMenu.ResumeLayout(false);
            this.MnStpMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnStpMenu;
        private System.Windows.Forms.ToolStripMenuItem TlSpMnItemCadVacina;
        private System.Windows.Forms.ToolStripMenuItem TlSpMnItemSobre;
        private System.Windows.Forms.ToolStripMenuItem TlSpMnItemSair;
    }
}

