﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace PVacina0030482023021
{
    public partial class FrmVacina : Form
    {
        private BindingSource bsVacina = new BindingSource();
        private bool bInclusao = false;

        private DataSet dsVacina = new DataSet();
        private DataSet dsCidade = new DataSet();
        private DataSet dsEnfermeiro = new DataSet();


        public FrmVacina()
        {
            InitializeComponent();

        }

        private void FrmVacina_Load(object sender, EventArgs e)
        {


            try
            {
                Vacina Vac = new Vacina(); // criar objeto
                dsVacina.Tables.Add(Vac.Listar());
                bsVacina.DataSource = dsVacina.Tables["Vacina"];
                BnVacina.BindingSource = bsVacina;
                DgVacina.DataSource = bsVacina;

                TxtIdVacina.DataBindings.Add("Text", bsVacina, "id_vacina");
                TxtNome.DataBindings.Add("Text", bsVacina, "nome_vacina");
                TxtDataNascVacina.DataBindings.Add("Text", bsVacina, "datanasc_vacina");
                TxtEndVacina.DataBindings.Add("Text", bsVacina, "end_vacina");
               // CbxCidade.DataBindings.Add("Text", bsVacina, "cidade_id_cidade");
                MskBxCPFVacina.DataBindings.Add("Text", bsVacina, "cpf_vacina");
                MskBxRgVacina.DataBindings.Add("Text", bsVacina, "rg_vacina");
                TxtDataVacinacao.DataBindings.Add("Text", bsVacina, "data_vacina");
                CbxTipoVacina.DataBindings.Add("SelectedItem", bsVacina, "tipo_vacina");
                CbxComorbidadeVacina.DataBindings.Add("SelectedItem", bsVacina, "comorbidade_vacina");
                CbxGrupoPrior.DataBindings.Add("SelectedItem", bsVacina, "grupopriori_vacina");
                // CbxEnfermeiro.DataBindings.Add("Text", bsVacina, "enfermeiro_id_enfermeiro");
               
                Cidade Cid = new Cidade(); //Objeto
                dsCidade.Tables.Add(Cid.Listar()); //Carregar nos nomes, baseado no índice.
                CbxCidade.DataSource = dsCidade.Tables["Cidade"];
                CbxCidade.DisplayMember = "nome_cidade";
                CbxCidade.ValueMember = "id_cidade";
                CbxCidade.DataBindings.Add("SelectedValue", bsVacina, "cidade_id_cidade");


                Enfermeiro Enf = new Enfermeiro(); //Objeto
                dsEnfermeiro.Tables.Add(Enf.Listar()); //Carregar nos nomes, baseado no índice.
                CbxEnfermeiro.DataSource = dsEnfermeiro.Tables["Enfermeiro"];
                CbxEnfermeiro.DisplayMember = "nome_enfermeiro";
                CbxEnfermeiro.ValueMember = "id_enfermeiro";
                CbxEnfermeiro.DataBindings.Add("SelectedValue", bsVacina, "enfermeiro_id_enfermeiro");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnIncluit_Click(object sender, EventArgs e)
        {
            if (TbVacina.SelectedIndex == 0)
            {
                TbVacina.SelectTab(1);
            }
            bsVacina.AddNew();

            



            TxtNome.Enabled = true;
            TxtDataNascVacina.Enabled = true;
            TxtEndVacina.Enabled = true;
            CbxCidade.Enabled = true;
            MskBxCPFVacina.Enabled = true;
            MskBxRgVacina.Enabled = true;
            TxtDataVacinacao.Enabled = true;
            CbxTipoVacina.Enabled = true;
            CbxComorbidadeVacina.Enabled = true;
            CbxGrupoPrior.Enabled = true;
            CbxEnfermeiro.Enabled = true;
            CbxTipoVacina.SelectedIndex = 0;
            CbxComorbidadeVacina.SelectedIndex = 0;
            CbxGrupoPrior.SelectedIndex = 0;
            CbxCidade.SelectedIndex = 0;
            CbxEnfermeiro.SelectedIndex = 0;



            BtnIncluir.Enabled = false;
            BtnSalvar.Enabled = true;
            BtnAlterar.Enabled = false;
            BtnExcluir.Enabled = false;
            BtnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            DateTime data;

            // validar os dados
            if (TxtNome.Text == "")
                MessageBox.Show("Nome inválido!");
            else
            if (!DateTime.TryParse(TxtDataNascVacina.Value.ToString(), out data))
                MessageBox.Show("Data inválida!");
            else
            if (MskBxCPFVacina.Text == "")
                MessageBox.Show("CPF inválido!");
            else
            if (MskBxRgVacina.Text == "")
                MessageBox.Show("RG inválido!");
            else
            if (!DateTime.TryParse(TxtDataVacinacao.Value.ToString(), out data))
                MessageBox.Show("Data inválida!");
            else
            {
                Vacina RegVac = new Vacina();

                RegVac.NomeVacina = TxtNome.Text;
                RegVac.EndVacina = TxtEndVacina.Text;
                RegVac.DataNascVacina = TxtDataNascVacina.Value;
                RegVac.CidadeIdCidade = Convert.ToInt32(CbxCidade.SelectedValue);
                RegVac.CpfVacina = MskBxCPFVacina.Text;
                RegVac.RgVacina = MskBxRgVacina.Text;
                RegVac.DataVacina = TxtDataNascVacina.Value;
                RegVac.TipoVacina = Convert.ToChar(CbxTipoVacina.SelectedItem.ToString());
                RegVac.GrupoPrioriVacina = Convert.ToChar(CbxGrupoPrior.SelectedItem.ToString());
                RegVac.ComorbidadeVacina = Convert.ToChar(CbxComorbidadeVacina.SelectedItem.ToString());
                RegVac.EnfermeiroIdEnfermeiro = Convert.ToInt32(CbxEnfermeiro.SelectedValue);

                if (bInclusao)
                {
                    if (RegVac.Salvar() > 0)
                    {
                        MessageBox.Show("Vacina adicionada com sucesso!");

                        TxtNome.Enabled = false;
                        TxtDataNascVacina.Enabled = false;
                        TxtEndVacina.Enabled = false;
                        CbxCidade.Enabled = false;
                        MskBxCPFVacina.Enabled = false;
                        MskBxRgVacina.Enabled = false;
                        TxtDataVacinacao.Enabled = false;
                        CbxTipoVacina.Enabled = false;
                        CbxComorbidadeVacina.Enabled = false;
                        CbxGrupoPrior.Enabled = false;
                        CbxEnfermeiro.Enabled = false;

                        BtnIncluir.Enabled = true;
                        BtnSalvar.Enabled = false;
                        BtnAlterar.Enabled = true;
                        BtnExcluir.Enabled = true;
                        BtnCancelar.Enabled = false;
                        bInclusao = false;

                        // recarrega o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bsVacina.DataSource = dsVacina.Tables["Vacina"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar vacina!");
                    }
                }
                else
                {
                        RegVac.IdVacina = Convert.ToInt32(TxtIdVacina.Text);

                    if (RegVac.Alterar() > 0)
                    {
                        MessageBox.Show("Vacina alterada com sucesso!");

                        TxtNome.Enabled = false;
                        TxtDataNascVacina.Enabled = false;
                        TxtEndVacina.Enabled = false;
                        CbxCidade.Enabled = false;
                        MskBxCPFVacina.Enabled = false;
                        MskBxRgVacina.Enabled = false;
                        TxtDataVacinacao.Enabled = false;
                        CbxTipoVacina.Enabled = false;
                        CbxComorbidadeVacina.Enabled = false;
                        CbxGrupoPrior.Enabled = false;
                        CbxEnfermeiro.Enabled = false;


                        BtnIncluir.Enabled = true;
                        BtnSalvar.Enabled = false;
                        BtnAlterar.Enabled = true;
                        BtnExcluir.Enabled = true;
                        BtnCancelar.Enabled = false;

                        // recarrega o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bsVacina.DataSource = dsVacina.Tables["Vacina"];
                    }

                    else
                    {
                        MessageBox.Show("Erro ao alterar vacina!");
                    }
                }
            }
        }


        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            if (TbVacina.SelectedIndex == 0)
            {
                TbVacina.SelectTab(1);
            }

            if (MessageBox.Show("Confirma exclusão?", "Sim or Não", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Vacina RegVac = new Vacina();
                RegVac.IdVacina = Convert.ToInt32(TxtIdVacina.Text);
                if (RegVac.Excluir() > 0)
                {
                    MessageBox.Show("Vacina excluída com sucesso!");

                    // recarrega o grid
                    dsVacina.Tables.Clear();
                    dsVacina.Tables.Add(RegVac.Listar());
                    bsVacina.DataSource = dsVacina.Tables["Vacina"];
                }
                else
                    MessageBox.Show("Erro ao excluir vacina!");
            }

        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            bsVacina.CancelEdit();



            TxtNome.Enabled = false;
            TxtDataNascVacina.Enabled = false;
            TxtEndVacina.Enabled = false;
            CbxCidade.Enabled = false;
            MskBxCPFVacina.Enabled = false;
            MskBxRgVacina.Enabled = false;
            TxtDataVacinacao.Enabled = false;
            CbxTipoVacina.Enabled = false;
            CbxComorbidadeVacina.Enabled = false;
            CbxGrupoPrior.Enabled = false;
            CbxEnfermeiro.Enabled = false;



            BtnIncluir.Enabled = true;
            BtnSalvar.Enabled = false;
            BtnAlterar.Enabled = true;
            BtnExcluir.Enabled = true;
            BtnCancelar.Enabled = false;



            bInclusao = false;
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            TxtNome.Enabled = true;
            TxtDataNascVacina.Enabled = true;
            TxtEndVacina.Enabled = true;
            CbxCidade.Enabled = true;
            MskBxCPFVacina.Enabled = true;
            MskBxRgVacina.Enabled = true;
            TxtDataVacinacao.Enabled = true;
            CbxTipoVacina.Enabled = true;
            CbxComorbidadeVacina.Enabled = true;
            CbxGrupoPrior.Enabled = true;
            CbxEnfermeiro.Enabled = true;
            BtnIncluir.Enabled = false;
            BtnSalvar.Enabled = true;
            BtnAlterar.Enabled = false;
            BtnExcluir.Enabled = false;
            BtnCancelar.Enabled = true;
            bInclusao = false;
        }
    }

}
