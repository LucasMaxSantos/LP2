﻿
namespace PVacina0030482023021
{
    partial class FrmVacina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmVacina));
            this.BnVacina = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnIncluir = new System.Windows.Forms.ToolStripButton();
            this.BtnSalvar = new System.Windows.Forms.ToolStripButton();
            this.BtnAlterar = new System.Windows.Forms.ToolStripButton();
            this.BtnExcluir = new System.Windows.Forms.ToolStripButton();
            this.BtnCancelar = new System.Windows.Forms.ToolStripButton();
            this.BtnSair = new System.Windows.Forms.ToolStripButton();
            this.TbVacina = new System.Windows.Forms.TabControl();
            this.TbPgDados = new System.Windows.Forms.TabPage();
            this.DgVacina = new System.Windows.Forms.DataGridView();
            this.TbPgDetalhes = new System.Windows.Forms.TabPage();
            this.CbxEnfermeiro = new System.Windows.Forms.ComboBox();
            this.CbxCidade = new System.Windows.Forms.ComboBox();
            this.PnImagem = new System.Windows.Forms.Panel();
            this.CbxGrupoPrior = new System.Windows.Forms.ComboBox();
            this.CbxComorbidadeVacina = new System.Windows.Forms.ComboBox();
            this.CbxTipoVacina = new System.Windows.Forms.ComboBox();
            this.TxtDataVacinacao = new System.Windows.Forms.DateTimePicker();
            this.TxtEndVacina = new System.Windows.Forms.TextBox();
            this.MskBxRgVacina = new System.Windows.Forms.MaskedTextBox();
            this.MskBxCPFVacina = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtDataNascVacina = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtIdVacina = new System.Windows.Forms.TextBox();
            this.LblPessoa = new System.Windows.Forms.Label();
            this.LblId = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.BnVacina)).BeginInit();
            this.BnVacina.SuspendLayout();
            this.TbVacina.SuspendLayout();
            this.TbPgDados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgVacina)).BeginInit();
            this.TbPgDetalhes.SuspendLayout();
            this.SuspendLayout();
            // 
            // BnVacina
            // 
            this.BnVacina.AddNewItem = null;
            this.BnVacina.CountItem = this.bindingNavigatorCountItem;
            this.BnVacina.DeleteItem = null;
            this.BnVacina.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.BnVacina.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.BtnIncluir,
            this.BtnSalvar,
            this.BtnAlterar,
            this.BtnExcluir,
            this.BtnCancelar,
            this.BtnSair});
            this.BnVacina.Location = new System.Drawing.Point(0, 0);
            this.BnVacina.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.BnVacina.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.BnVacina.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.BnVacina.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.BnVacina.Name = "BnVacina";
            this.BnVacina.PositionItem = this.bindingNavigatorPositionItem;
            this.BnVacina.Size = new System.Drawing.Size(1302, 27);
            this.BnVacina.TabIndex = 0;
            this.BnVacina.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(48, 24);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(56, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // BtnIncluir
            // 
            this.BtnIncluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnIncluir.Image = ((System.Drawing.Image)(resources.GetObject("BtnIncluir.Image")));
            this.BtnIncluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnIncluir.Name = "BtnIncluir";
            this.BtnIncluir.Size = new System.Drawing.Size(29, 24);
            this.BtnIncluir.Text = "Novo Registro";
            this.BtnIncluir.Click += new System.EventHandler(this.BtnIncluit_Click);
            // 
            // BtnSalvar
            // 
            this.BtnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnSalvar.Enabled = false;
            this.BtnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("BtnSalvar.Image")));
            this.BtnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSalvar.Name = "BtnSalvar";
            this.BtnSalvar.Size = new System.Drawing.Size(29, 24);
            this.BtnSalvar.Text = "Salvar";
            this.BtnSalvar.Click += new System.EventHandler(this.BtnSalvar_Click);
            // 
            // BtnAlterar
            // 
            this.BtnAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnAlterar.Image = ((System.Drawing.Image)(resources.GetObject("BtnAlterar.Image")));
            this.BtnAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAlterar.Name = "BtnAlterar";
            this.BtnAlterar.Size = new System.Drawing.Size(29, 24);
            this.BtnAlterar.Text = "Editar";
            this.BtnAlterar.Click += new System.EventHandler(this.BtnAlterar_Click);
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("BtnExcluir.Image")));
            this.BtnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Size = new System.Drawing.Size(29, 24);
            this.BtnExcluir.Text = "Excluir";
            this.BtnExcluir.Click += new System.EventHandler(this.BtnExcluir_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnCancelar.Enabled = false;
            this.BtnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("BtnCancelar.Image")));
            this.BtnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(29, 24);
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnSair.Image = ((System.Drawing.Image)(resources.GetObject("BtnSair.Image")));
            this.BtnSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(29, 24);
            this.BtnSair.Text = "Sair";
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // TbVacina
            // 
            this.TbVacina.Controls.Add(this.TbPgDados);
            this.TbVacina.Controls.Add(this.TbPgDetalhes);
            this.TbVacina.Location = new System.Drawing.Point(14, 43);
            this.TbVacina.Name = "TbVacina";
            this.TbVacina.SelectedIndex = 0;
            this.TbVacina.Size = new System.Drawing.Size(1271, 559);
            this.TbVacina.TabIndex = 1;
            // 
            // TbPgDados
            // 
            this.TbPgDados.Controls.Add(this.DgVacina);
            this.TbPgDados.Location = new System.Drawing.Point(4, 25);
            this.TbPgDados.Name = "TbPgDados";
            this.TbPgDados.Padding = new System.Windows.Forms.Padding(3);
            this.TbPgDados.Size = new System.Drawing.Size(1263, 530);
            this.TbPgDados.TabIndex = 0;
            this.TbPgDados.Text = "Dados";
            this.TbPgDados.UseVisualStyleBackColor = true;
            // 
            // DgVacina
            // 
            this.DgVacina.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgVacina.Location = new System.Drawing.Point(0, 3);
            this.DgVacina.Name = "DgVacina";
            this.DgVacina.RowHeadersWidth = 51;
            this.DgVacina.RowTemplate.Height = 24;
            this.DgVacina.Size = new System.Drawing.Size(1256, 521);
            this.DgVacina.TabIndex = 0;
            // 
            // TbPgDetalhes
            // 
            this.TbPgDetalhes.BackColor = System.Drawing.Color.SkyBlue;
            this.TbPgDetalhes.Controls.Add(this.CbxEnfermeiro);
            this.TbPgDetalhes.Controls.Add(this.CbxCidade);
            this.TbPgDetalhes.Controls.Add(this.PnImagem);
            this.TbPgDetalhes.Controls.Add(this.CbxGrupoPrior);
            this.TbPgDetalhes.Controls.Add(this.CbxComorbidadeVacina);
            this.TbPgDetalhes.Controls.Add(this.CbxTipoVacina);
            this.TbPgDetalhes.Controls.Add(this.TxtDataVacinacao);
            this.TbPgDetalhes.Controls.Add(this.TxtEndVacina);
            this.TbPgDetalhes.Controls.Add(this.MskBxRgVacina);
            this.TbPgDetalhes.Controls.Add(this.MskBxCPFVacina);
            this.TbPgDetalhes.Controls.Add(this.label10);
            this.TbPgDetalhes.Controls.Add(this.label9);
            this.TbPgDetalhes.Controls.Add(this.label8);
            this.TbPgDetalhes.Controls.Add(this.label7);
            this.TbPgDetalhes.Controls.Add(this.label6);
            this.TbPgDetalhes.Controls.Add(this.label5);
            this.TbPgDetalhes.Controls.Add(this.label4);
            this.TbPgDetalhes.Controls.Add(this.label3);
            this.TbPgDetalhes.Controls.Add(this.label2);
            this.TbPgDetalhes.Controls.Add(this.TxtDataNascVacina);
            this.TbPgDetalhes.Controls.Add(this.label1);
            this.TbPgDetalhes.Controls.Add(this.TxtNome);
            this.TbPgDetalhes.Controls.Add(this.TxtIdVacina);
            this.TbPgDetalhes.Controls.Add(this.LblPessoa);
            this.TbPgDetalhes.Controls.Add(this.LblId);
            this.TbPgDetalhes.Location = new System.Drawing.Point(4, 25);
            this.TbPgDetalhes.Name = "TbPgDetalhes";
            this.TbPgDetalhes.Padding = new System.Windows.Forms.Padding(3);
            this.TbPgDetalhes.Size = new System.Drawing.Size(1263, 530);
            this.TbPgDetalhes.TabIndex = 1;
            this.TbPgDetalhes.Text = "Detalhes";
            // 
            // CbxEnfermeiro
            // 
            this.CbxEnfermeiro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxEnfermeiro.Enabled = false;
            this.CbxEnfermeiro.FormattingEnabled = true;
            this.CbxEnfermeiro.ItemHeight = 16;
            this.CbxEnfermeiro.Location = new System.Drawing.Point(187, 434);
            this.CbxEnfermeiro.Name = "CbxEnfermeiro";
            this.CbxEnfermeiro.Size = new System.Drawing.Size(175, 24);
            this.CbxEnfermeiro.TabIndex = 26;
            // 
            // CbxCidade
            // 
            this.CbxCidade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxCidade.Enabled = false;
            this.CbxCidade.FormattingEnabled = true;
            this.CbxCidade.Location = new System.Drawing.Point(187, 239);
            this.CbxCidade.Name = "CbxCidade";
            this.CbxCidade.Size = new System.Drawing.Size(175, 24);
            this.CbxCidade.TabIndex = 7;
            // 
            // PnImagem
            // 
            this.PnImagem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PnImagem.BackgroundImage")));
            this.PnImagem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PnImagem.Location = new System.Drawing.Point(660, 6);
            this.PnImagem.Name = "PnImagem";
            this.PnImagem.Size = new System.Drawing.Size(597, 518);
            this.PnImagem.TabIndex = 24;
            // 
            // CbxGrupoPrior
            // 
            this.CbxGrupoPrior.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxGrupoPrior.Enabled = false;
            this.CbxGrupoPrior.FormattingEnabled = true;
            this.CbxGrupoPrior.Items.AddRange(new object[] {
            "S",
            "N"});
            this.CbxGrupoPrior.Location = new System.Drawing.Point(187, 353);
            this.CbxGrupoPrior.Name = "CbxGrupoPrior";
            this.CbxGrupoPrior.Size = new System.Drawing.Size(175, 24);
            this.CbxGrupoPrior.TabIndex = 10;
            // 
            // CbxComorbidadeVacina
            // 
            this.CbxComorbidadeVacina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxComorbidadeVacina.Enabled = false;
            this.CbxComorbidadeVacina.FormattingEnabled = true;
            this.CbxComorbidadeVacina.Items.AddRange(new object[] {
            "S",
            "N"});
            this.CbxComorbidadeVacina.Location = new System.Drawing.Point(187, 307);
            this.CbxComorbidadeVacina.Name = "CbxComorbidadeVacina";
            this.CbxComorbidadeVacina.Size = new System.Drawing.Size(175, 24);
            this.CbxComorbidadeVacina.TabIndex = 9;
            // 
            // CbxTipoVacina
            // 
            this.CbxTipoVacina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxTipoVacina.Enabled = false;
            this.CbxTipoVacina.FormattingEnabled = true;
            this.CbxTipoVacina.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.CbxTipoVacina.Location = new System.Drawing.Point(443, 273);
            this.CbxTipoVacina.Name = "CbxTipoVacina";
            this.CbxTipoVacina.Size = new System.Drawing.Size(175, 24);
            this.CbxTipoVacina.TabIndex = 8;
            // 
            // TxtDataVacinacao
            // 
            this.TxtDataVacinacao.CustomFormat = "dd/MM/yyyy";
            this.TxtDataVacinacao.Enabled = false;
            this.TxtDataVacinacao.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TxtDataVacinacao.Location = new System.Drawing.Point(187, 391);
            this.TxtDataVacinacao.Name = "TxtDataVacinacao";
            this.TxtDataVacinacao.Size = new System.Drawing.Size(127, 22);
            this.TxtDataVacinacao.TabIndex = 11;
            // 
            // TxtEndVacina
            // 
            this.TxtEndVacina.Enabled = false;
            this.TxtEndVacina.Location = new System.Drawing.Point(187, 206);
            this.TxtEndVacina.MaxLength = 100;
            this.TxtEndVacina.Name = "TxtEndVacina";
            this.TxtEndVacina.Size = new System.Drawing.Size(399, 22);
            this.TxtEndVacina.TabIndex = 6;
            // 
            // MskBxRgVacina
            // 
            this.MskBxRgVacina.Enabled = false;
            this.MskBxRgVacina.Location = new System.Drawing.Point(187, 136);
            this.MskBxRgVacina.Mask = "99.999.999-9";
            this.MskBxRgVacina.Name = "MskBxRgVacina";
            this.MskBxRgVacina.Size = new System.Drawing.Size(198, 22);
            this.MskBxRgVacina.TabIndex = 4;
            this.MskBxRgVacina.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // MskBxCPFVacina
            // 
            this.MskBxCPFVacina.Enabled = false;
            this.MskBxCPFVacina.Location = new System.Drawing.Point(187, 96);
            this.MskBxCPFVacina.Mask = "999.999.999-99";
            this.MskBxCPFVacina.Name = "MskBxCPFVacina";
            this.MskBxCPFVacina.Size = new System.Drawing.Size(198, 22);
            this.MskBxCPFVacina.TabIndex = 3;
            this.MskBxCPFVacina.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 434);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 17);
            this.label10.TabIndex = 14;
            this.label10.Text = "Enfermeiro";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 360);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 17);
            this.label9.TabIndex = 13;
            this.label9.Text = "Grupo Prioritário?";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 314);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(148, 17);
            this.label8.TabIndex = 12;
            this.label8.Text = "Tem Comorbidade?";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(408, 17);
            this.label7.TabIndex = 11;
            this.label7.Text = "Tipo da Vacina (a-Coronavac; 2-Astrazeneca; 3-Pfizer)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 396);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Data Vacinação";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "RG";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "CPF";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 239);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Cidade";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Endereço";
            // 
            // TxtDataNascVacina
            // 
            this.TxtDataNascVacina.CustomFormat = "dd/MM/yyyy";
            this.TxtDataNascVacina.Enabled = false;
            this.TxtDataNascVacina.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TxtDataNascVacina.Location = new System.Drawing.Point(187, 170);
            this.TxtDataNascVacina.Name = "TxtDataNascVacina";
            this.TxtDataNascVacina.Size = new System.Drawing.Size(128, 22);
            this.TxtDataNascVacina.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Data de Nascimento";
            // 
            // TxtNome
            // 
            this.TxtNome.Enabled = false;
            this.TxtNome.Location = new System.Drawing.Point(187, 59);
            this.TxtNome.MaxLength = 50;
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(399, 22);
            this.TxtNome.TabIndex = 2;
            // 
            // TxtIdVacina
            // 
            this.TxtIdVacina.Enabled = false;
            this.TxtIdVacina.Location = new System.Drawing.Point(187, 23);
            this.TxtIdVacina.Name = "TxtIdVacina";
            this.TxtIdVacina.Size = new System.Drawing.Size(112, 22);
            this.TxtIdVacina.TabIndex = 1;
            // 
            // LblPessoa
            // 
            this.LblPessoa.AutoSize = true;
            this.LblPessoa.Location = new System.Drawing.Point(22, 59);
            this.LblPessoa.Name = "LblPessoa";
            this.LblPessoa.Size = new System.Drawing.Size(130, 17);
            this.LblPessoa.TabIndex = 1;
            this.LblPessoa.Text = "Nome da Pessoa";
            // 
            // LblId
            // 
            this.LblId.AutoSize = true;
            this.LblId.Location = new System.Drawing.Point(22, 23);
            this.LblId.Name = "LblId";
            this.LblId.Size = new System.Drawing.Size(21, 17);
            this.LblId.TabIndex = 0;
            this.LblId.Text = "Id";
            // 
            // FrmVacina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(1302, 627);
            this.Controls.Add(this.TbVacina);
            this.Controls.Add(this.BnVacina);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FrmVacina";
            this.Text = "FrmVacina";
            this.Load += new System.EventHandler(this.FrmVacina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BnVacina)).EndInit();
            this.BnVacina.ResumeLayout(false);
            this.BnVacina.PerformLayout();
            this.TbVacina.ResumeLayout(false);
            this.TbPgDados.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgVacina)).EndInit();
            this.TbPgDetalhes.ResumeLayout(false);
            this.TbPgDetalhes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingNavigator BnVacina;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.TabControl TbVacina;
        private System.Windows.Forms.TabPage TbPgDados;
        private System.Windows.Forms.TabPage TbPgDetalhes;
        private System.Windows.Forms.DataGridView DgVacina;
        private System.Windows.Forms.ToolStripButton BtnIncluir;
        private System.Windows.Forms.ToolStripButton BtnSalvar;
        private System.Windows.Forms.ToolStripButton BtnAlterar;
        private System.Windows.Forms.ToolStripButton BtnExcluir;
        private System.Windows.Forms.ToolStripButton BtnCancelar;
        private System.Windows.Forms.ToolStripButton BtnSair;
        private System.Windows.Forms.DateTimePicker TxtDataVacinacao;
        private System.Windows.Forms.TextBox TxtEndVacina;
        private System.Windows.Forms.MaskedTextBox MskBxRgVacina;
        private System.Windows.Forms.MaskedTextBox MskBxCPFVacina;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker TxtDataNascVacina;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtIdVacina;
        private System.Windows.Forms.Label LblPessoa;
        private System.Windows.Forms.Label LblId;
        private System.Windows.Forms.ComboBox CbxGrupoPrior;
        private System.Windows.Forms.ComboBox CbxComorbidadeVacina;
        private System.Windows.Forms.ComboBox CbxTipoVacina;
        private System.Windows.Forms.Panel PnImagem;
        private System.Windows.Forms.ComboBox CbxEnfermeiro;
        private System.Windows.Forms.ComboBox CbxCidade;
    }
}