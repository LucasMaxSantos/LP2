﻿
namespace PVacina0030482023021
{
    partial class FrmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PnImagem = new System.Windows.Forms.Panel();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblPVacina = new System.Windows.Forms.Label();
            this.LblVersao = new System.Windows.Forms.Label();
            this.LblCopyright = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LblInfo = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnImagem
            // 
            this.PnImagem.BackgroundImage = global::PVacina0030482023021.Properties.Resources.Sobre;
            this.PnImagem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PnImagem.Location = new System.Drawing.Point(15, 14);
            this.PnImagem.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PnImagem.Name = "PnImagem";
            this.PnImagem.Size = new System.Drawing.Size(433, 431);
            this.PnImagem.TabIndex = 0;
            // 
            // BtnOk
            // 
            this.BtnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnOk.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnOk.Location = new System.Drawing.Point(844, 461);
            this.BtnOk.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(140, 30);
            this.BtnOk.TabIndex = 25;
            this.BtnOk.Text = "&OK";
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // LblPVacina
            // 
            this.LblPVacina.AutoSize = true;
            this.LblPVacina.Location = new System.Drawing.Point(470, 40);
            this.LblPVacina.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblPVacina.Name = "LblPVacina";
            this.LblPVacina.Size = new System.Drawing.Size(69, 18);
            this.LblPVacina.TabIndex = 26;
            this.LblPVacina.Text = "PVacina";
            // 
            // LblVersao
            // 
            this.LblVersao.AutoSize = true;
            this.LblVersao.Location = new System.Drawing.Point(470, 91);
            this.LblVersao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblVersao.Name = "LblVersao";
            this.LblVersao.Size = new System.Drawing.Size(89, 18);
            this.LblVersao.TabIndex = 27;
            this.LblVersao.Text = "Versão 2.1";
            // 
            // LblCopyright
            // 
            this.LblCopyright.AutoSize = true;
            this.LblCopyright.Location = new System.Drawing.Point(470, 149);
            this.LblCopyright.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblCopyright.Name = "LblCopyright";
            this.LblCopyright.Size = new System.Drawing.Size(138, 18);
            this.LblCopyright.TabIndex = 28;
            this.LblCopyright.Text = "Copyright © 2021";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(473, 250);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(480, 195);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Equipe:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 137);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(223, 18);
            this.label6.TabIndex = 34;
            this.label6.Text = "Mariana Rosária dos Santos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 90);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(238, 18);
            this.label5.TabIndex = 33;
            this.label5.Text = "Márcio Aurélio da Silva Calixto";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 42);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(230, 18);
            this.label4.TabIndex = 32;
            this.label4.Text = "Lucas Maximiano dos Santos";
            // 
            // LblInfo
            // 
            this.LblInfo.AutoSize = true;
            this.LblInfo.Location = new System.Drawing.Point(470, 194);
            this.LblInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblInfo.Name = "LblInfo";
            this.LblInfo.Size = new System.Drawing.Size(410, 23);
            this.LblInfo.TabIndex = 30;
            this.LblInfo.Text = "Projeto de conclusão 1º semestre de 2021";
            // 
            // FrmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(1000, 506);
            this.Controls.Add(this.LblInfo);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.LblCopyright);
            this.Controls.Add(this.LblVersao);
            this.Controls.Add(this.LblPVacina);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.PnImagem);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmSobre";
            this.Text = "Sobre";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PnImagem;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Label LblPVacina;
        private System.Windows.Forms.Label LblVersao;
        private System.Windows.Forms.Label LblCopyright;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label LblInfo;
    }
}